import React, { Component } from "react";
import BookingService from "../../services/BookingService";
import DropDownUserName from "../../DropDownComponents/DropDownUserName";
import CoSpacePlanServiceService from "../../services/CoSpacePlanServiceService";
import SerIDPlanIDDropDown from "../../DropDownComponents/SerIDPlanIDDropDown";
import DropDownCoSpace from "../../DropDownComponents/DropDownCoSpace";

import CascadingDropdown from "../../DropDownComponents/CascadingDropdown";

class bookForMe extends Component {
  constructor(props) {
    console.log("book for me ctor");
    super(props);

    this.state = {
      
    };
    
  }

  

  render() {
    return (
      <div>
        <CascadingDropdown />
      </div>
    );
  }
}

export default bookForMe;
