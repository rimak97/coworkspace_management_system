import React, { Component } from "react";
import BookingService from "../../services/BookingService";
import TextField from "@material-ui/core/TextField";
import DropDownUserName from "../../DropDownComponents/DropDownUserName";
import DropDownCoSpace from "../../DropDownComponents/DropDownCoSpace";
import DropDownPlanType from "../../DropDownComponents/DropDownPlanType";
import DropDownServiceType from "../../DropDownComponents/DropDownServiceType";

class CreateBookingComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      bookingID: this.props.match.params.bookingID,
      userID: "",
      coworkID: "",
      startDate: "",
      bookedQty: "",
      amount: "",
      finalAmount: "",
      serviceTypeID: "",
      planTypeID: "",
      billingID: "",
    };
    this.changeUserIDHandler = this.changeUserIDHandler.bind(this);
    this.changeCoworkIDHandler = this.changeCoworkIDHandler.bind(this);
    this.changeStartDateHandler = this.changeStartDateHandler.bind(this);

    this.changeBookedQtyHandler = this.changeBookedQtyHandler.bind(this);
    this.changeAmountHandler = this.changeAmountHandler.bind(this);
    this.changeFinalAmountHandler = this.changeFinalAmountHandler.bind(this);
    this.changeServiceTypeIDHandler =
      this.changeServiceTypeIDHandler.bind(this);
    this.changePlanTypeIDHandler = this.changePlanTypeIDHandler.bind(this);
    this.changeBillingIDHandler = this.changeBillingIDHandler.bind(this);

    this.saveOrUpdateBooking = this.saveOrUpdateBooking.bind(this);
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.bookingID === "_add") {
      return;
    } else {
      BookingService.getBookingById(this.state.bookingID).then((res) => {
        let booking = res.data;

        this.setState({
          userID: booking.data[0].userID,
          coworkID: booking.data[0].coworkID,
          startDate: booking.data[0].startDate,

          bookedQty: booking.data[0].bookedQty,
          amount: booking.data[0].amount,
          finalAmount: booking.data[0].finalAmount,
          serviceTypeID: booking.data[0].serviceTypeID,
          planTypeID: booking.data[0].planTypeID,
          billingID: booking.data[0].billingID,
        });
      });
    }
  }
  saveOrUpdateBooking = (e) => {
    e.preventDefault();
    let booking = {
      userID: this.state.userID,
      coworkID: this.state.coworkID,
      startDate: this.state.startDate,

      bookedQty: this.state.bookedQty,
      amount: this.state.amount,
      finalAmount: this.state.finalAmount,
      serviceTypeID: this.state.serviceTypeID,
      planTypeID: this.state.planTypeID,
      billingID: this.state.billingID,
    };
    console.log("booking => " + JSON.stringify(booking));

    // step 5
    if (this.state.bookingID === "_add") {
      BookingService.createBooking(booking).then((res) => {
        this.props.history.push("/bookings");
      });
    } else {
      console.log("In Update Code");
      BookingService.updateBooking(booking, this.state.bookingID).then(
        (res) => {
          this.props.history.push("/bookings");
        }
      );
    }
  };

  changeUserIDHandler = (event) => {
    this.setState({ userID: event.target.value });
  };

  changeCoworkIDHandler = (event) => {
    this.setState({ coworkID: event.target.value });
  };

  changeStartDateHandler = (event) => {
    // const tempData=event.target.value;

    this.setState({ startDate: event.target.value });
  };

  changeBookedQtyHandler = (event) => {
    this.setState({ bookedQty: event.target.value });
  };

  changeAmountHandler = (event) => {
    this.setState({ amount: event.target.value });
  };

  changeFinalAmountHandler = (event) => {
    this.setState({ finalAmount: event.target.value });
  };

  changeServiceTypeIDHandler = (event) => {
    this.setState({ serviceTypeID: event.target.value });
  };

  changePlanTypeIDHandler = (event) => {
    this.setState({ planTypeID: event.target.value });
  };

  changeBillingIDHandler = (event) => {
    this.setState({ billingID: event.target.value });
  };

  // onChange = startDate => this.setState({ startDate })

  cancel() {
    this.props.history.push("/bookings");
  }

  getTitle() {
    if (this.state.bookingID === "_add") {
      return <h3 className="text-center">Add Booking</h3>;
    } else {
      return <h3 className="text-center">Update Booking</h3>;
    }
  }

  callbackFunctionForUserNameDropDown = (childData) => {
    this.setState({ userID: childData });
  };

  callbackFunctionForPlanTypeDropDown = (childData) => {
    this.setState({ planTypeID: childData });
  };

  callbackFunctionForCoSpaceDropDown = (childData) => {
    this.setState({ coworkID: childData });
  };

  callbackFunctionForServiceTypeDropDown = (childData) => {
    this.setState({ serviceTypeID: childData });
  };

  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-header bg-warning">{this.getTitle()}</div>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label>
                      {" "}
                      User Name:
                      <DropDownUserName
                        parentCallback={
                          this.callbackFunctionForUserNameDropDown
                        }
                      />
                    </label>
                  </div>

                  <div className="form-group">
                    <label>
                      {" "}
                      CoWork Space Name:
                      <DropDownCoSpace
                        parentCallback={this.callbackFunctionForCoSpaceDropDown}
                      />
                    </label>
                  </div>

                  <div className="form-group">
                    <label>
                      {" "}
                      Select Service Type:
                      <DropDownServiceType
                        parentCallback={
                          this.callbackFunctionForServiceTypeDropDown
                        }
                      />
                    </label>
                  </div>

                  <div className="form-group">
                    <label>
                      {" "}
                      Select Plan Type:
                      <DropDownPlanType
                        parentCallback={
                          this.callbackFunctionForPlanTypeDropDown
                        }
                      />
                    </label>
                  </div>

                  <div className="form-group">
                    <label> User Name: </label>
                    <input
                      placeholder="User ID"
                      name="userID"
                      className="form-control"
                      value={this.state.userID}
                      onChange={this.changeUserIDHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> CoWork Name: </label>
                    <input
                      placeholder="CoWork ID"
                      name="coworkID"
                      className="form-control"
                      value={this.state.coworkID}
                      onChange={this.changeCoworkIDHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Service Type: </label>
                    <input
                      placeholder="Service Type ID"
                      name="serviceTypeID"
                      className="form-control"
                      value={this.state.serviceTypeID}
                      onChange={this.changeServiceTypeIDHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Plan Type: </label>
                    <input
                      placeholder="Plan Type ID"
                      name="planTypeID"
                      className="form-control"
                      value={this.state.planTypeID}
                      onChange={this.changePlanTypeIDHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Start Date: </label>
                    <br></br>
                    <TextField
                      id="date"
                      type="date"
                      onChange={(e) => {
                        this.setState({ startDate: e.target.value });
                      }}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </div>

                  {/* <div className="form-group">
                    <label> Start Date: </label>
                    <input
                      placeholder="Start Date"
                      name="startDate"
                      className="form-control"
                      value={this.state.startDate}
                      onChange={this.changeStartDateHandler}
                    />
                  </div> */}

                  {/* <div className="form-group">
                    <label> End Date: </label>
                    <input
                      placeholder="End Date"
                      name="endDate"
                      className="form-control"
                      value={this.state.endDate}
                      onChange={this.changeEndDateHandler}
                    />
                  </div> */}

                  <div className="form-group">
                    <label> Booked Qty: </label>
                    <input
                      placeholder="Booked Qty"
                      name="bookedQty"
                      className="form-control"
                      value={this.state.bookedQty}
                      onChange={this.changeBookedQtyHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Amount: </label>
                    <input
                      placeholder="Amount"
                      name="amount"
                      className="form-control"
                      value={this.state.amount}
                      onChange={this.changeAmountHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Final Amount: </label>
                    <input
                      placeholder="Final Amount"
                      name="finalAmount"
                      className="form-control"
                      value={this.state.finalAmount}
                      onChange={this.changeFinalAmountHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Billing ID: </label>
                    <input
                      placeholder="Billing ID"
                      name="billingID"
                      className="form-control"
                      value={this.state.billingID}
                      onChange={this.changeBillingIDHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdateBooking}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateBookingComponent;
