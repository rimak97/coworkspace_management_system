import React, { Component } from "react";
import BookingService from "../../services/BookingService";

class ViewBookingComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      bookingID: this.props.match.params.bookingID,
      booking: {},
    };
  }

  componentDidMount() {
    BookingService.getBookingById(this.state.bookingID).then((res) => {
      console.log("Booking Data");
      console.log(res.data.data[0]);
      this.setState({ booking: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/bookings");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View Booking Details</h3>
          <div className="card-body">
            <div className="row">
              <label> User ID: </label>
              <div> {this.state.booking.userID}</div>
            </div>
            <div className="row">
              <label> CoWork ID: </label>
              <div> {this.state.booking.coworkID}</div>
            </div>
            <div className="row">
              <label> Service Type ID: </label>
              <div> {this.state.booking.serviceTypeID}</div>
            </div>
            <div className="row">
              <label> Plan Type ID: </label>
              <div> {this.state.booking.planTypeID}</div>
            </div>
            <div className="row">
              <label> Billing ID: </label>
              <div> {this.state.booking.billingID}</div>
            </div>
            <div className="row">
              <label> Start Date: </label>
              <div> {this.state.booking.startDate}</div>
            </div>

            <div className="row">
              <label> Booked Qty: </label>
              <div> {this.state.booking.bookedQty}</div>
            </div>
            <div className="row">
              <label> Amount: </label>
              <div> {this.state.booking.amount}</div>
            </div>
            <div className="row">
              <label> Final Amount: </label>
              <div> {this.state.booking.finalAmount}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewBookingComponent;
