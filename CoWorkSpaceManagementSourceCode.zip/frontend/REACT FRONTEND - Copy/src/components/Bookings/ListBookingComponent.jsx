import React, { Component } from "react";
import BookingService from "../../services/BookingService";

class ListBookingComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      bookings: [],
    };
    this.addBooking = this.addBooking.bind(this);
    this.editBooking = this.editBooking.bind(this);
    this.deleteBooking = this.deleteBooking.bind(this);
    this.bookForMe = this.bookForMeHandler.bind(this);
  }

  deleteBooking(bookingID) {
    BookingService.deleteBooking(bookingID).then((res) => {
      this.setState({
        bookings: this.state.bookings.filter(
          (booking) => booking.bookingID !== bookingID
        ),
      });
    });
  }
  viewBooking(bookingID) {
    this.props.history.push(`/view-booking/${bookingID}`);
  }
  editBooking(bookingID) {
    this.props.history.push(`/add-booking/${bookingID}`);
  }

  componentDidMount() {
    BookingService.getBookings().then((res) => {
      console.log(res.data.data);
      this.setState({ bookings: res.data.data });
    });
  }

  addBooking() {
    this.props.history.push("/add-booking/_add");
  }

  bookForMeHandler = () => {
    console.log("Book for Me");
    this.props.history.push("/bookForMe");
  };

  render() {
    return (
      <div>
        <h1 className="text-center text-white">Bookings List</h1>
        <div className="row">
          <button className="btn btn-primary" onClick={this.addBooking}>
            {" "}
            Add Booking
          </button>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button className="btn btn-primary" onClick={this.bookForMeHandler}>
            {" "}
            Book For Me
          </button>
        </div>
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> User ID</th>
                <th> CoWork Space ID</th>
                <th> Service Type ID</th>
                <th> Plan Type ID</th>
                <th> Billing ID</th>
                <th> Start Date</th>

                <th> Booked Qty</th>
                <th> Amount</th>
                <th> Final Amount</th>

                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.bookings.map((booking) => (
                <tr key={booking.bookingID}>
                  <td> {booking.firstName} </td>
                  <td> {booking.coworkName} </td>
                  <td> {booking.serviceTypeName}</td>
                  <td> {booking.planName}</td>
                  <td> {booking.billingID} </td>
                  <td> {booking.startDate} </td>

                  <td> {booking.bookedQty} </td>
                  <td> {booking.amount} </td>
                  <td> {booking.finalAmount} </td>
                  <td>
                    <button
                      onClick={() => this.editBooking(booking.bookingID)}
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.deleteBooking(booking.bookingID)}
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewBooking(booking.bookingID)}
                      className="btn btn-info"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListBookingComponent;
