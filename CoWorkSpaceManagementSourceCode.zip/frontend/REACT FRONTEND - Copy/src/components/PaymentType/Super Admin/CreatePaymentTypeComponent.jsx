import React, { Component } from "react";
import PaymentTypeService from "../../../services/PaymentTypeService";

class CreatePaymentTypeComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      paymentTypeID: this.props.match.params.paymentTypeID,
      paymentTypeName: "",
    };
    this.changePaymentTypeNameHandler =
      this.changePaymentTypeNameHandler.bind(this);
    this.saveOrUpdatePaymentType = this.saveOrUpdatePaymentType.bind(this);
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.paymentTypeID === "_add") {
      return;
    } else {
      PaymentTypeService.getPaymentTypeById(this.state.paymentTypeID).then(
        (res) => {
          console.log(res.data);
          let paymentType = res.data;
          //console.log(role.data[0].roleName)
          this.setState({
            paymentTypeName: paymentType.data[0].paymentTypeName,
          });
        }
      );
    }
  }
  saveOrUpdatePaymentType = (e) => {
    e.preventDefault();
    let paymentType = { paymentTypeName: this.state.paymentTypeName };
    console.log("paymentType => " + JSON.stringify(paymentType));

    // step 5
    if (this.state.paymentTypeID === "_add") {
      PaymentTypeService.createPaymentType(paymentType).then((res) => {
        this.props.history.push("/superAdminpaymentTypes");
      });
    } else {
      PaymentTypeService.updatePaymentType(
        paymentType,
        this.state.paymentTypeID
      ).then((res) => {
        this.props.history.push("/superAdminpaymentTypes");
      });
    }
  };

  changePaymentTypeNameHandler = (event) => {
    console.log("change PaymentType handler");
    this.setState({ paymentTypeName: event.target.value });
  };

  cancel() {
    this.props.history.push("/superAdminpaymentTypes");
  }

  getTitle() {
    if (this.state.paymentTypeID === "_add") {
      return <h3 className="text-center">Add Payment Type</h3>;
    } else {
      return <h3 className="text-center">Update Payment Type</h3>;
    }
  }
  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-header bg-warning">{this.getTitle()}</div>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> Payment Type Name: </label>
                    <input
                      placeholder="Payment Type Name"
                      name="paymentTypeName"
                      className="form-control"
                      value={this.state.paymentTypeName}
                      onChange={this.changePaymentTypeNameHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdatePaymentType}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreatePaymentTypeComponent;
