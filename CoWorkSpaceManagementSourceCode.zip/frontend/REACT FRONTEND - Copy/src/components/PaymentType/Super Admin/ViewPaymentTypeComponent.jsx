import React, { Component } from "react";
import PaymentTypeService from "../../../services/PaymentTypeService";

class ViewPaymentTypeComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      paymentTypeID: this.props.match.params.paymentTypeID,
      paymentType: {},
    };
  }

  componentDidMount() {
    PaymentTypeService.getPaymentTypeById(this.state.paymentTypeID).then(
      (res) => {
        console.log(res.data.data[0]);
        this.setState({ paymentType: res.data.data[0] });
      }
    );
  }

  cancel() {
    this.props.history.push("/superAdminpaymentTypes");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View PaymentType Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> PaymentTypeName: </label>
              <div> {this.state.paymentType.paymentTypeName}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewPaymentTypeComponent;
