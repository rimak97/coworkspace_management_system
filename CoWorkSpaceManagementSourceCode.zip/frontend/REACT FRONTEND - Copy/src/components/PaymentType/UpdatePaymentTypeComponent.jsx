import React, { Component } from "react";
import PaymentTypeService from "../../services/PaymentTypeService";

class UpdatePaymentTypeComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      paymentTypeID: this.props.match.params.paymentTypeID,
      paymentTypeName: "",
    };
    this.changePaymentTypeNameHandler =
      this.changePaymentTypeNameHandler.bind(this);

    this.updatePaymentType = this.updatePaymentType.bind(this);
  }

  componentDidMount() {
    PaymentTypeService.getPaymentTypeById(this.state.paymentTypeID).then(
      (res) => {
        let paymentType = res.data;
        this.setState({ paymentTypeName: paymentType.paymentTypeName });
      }
    );
  }

  updatePaymentType = (e) => {
    e.preventDefault();
    let paymentType = { paymentTypeName: this.state.paymentTypeName };
    console.log("paymentType => " + JSON.stringify(paymentType));
    console.log("paymentTypeID => " + JSON.stringify(this.state.paymentTypeID));
    PaymentTypeService.updatePaymentType(
      paymentType,
      this.state.paymentTypeID
    ).then((res) => {
      this.props.history.push("/paymentTypes");
    });
  };

  changePaymentTypeNameHandler = (event) => {
    this.setState({ paymentTypeName: event.target.value });
  };

  cancel() {
    this.props.history.push("/paymentTypes");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-center">Update Payment Type</h3>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> paymentTypeName: </label>
                    <input
                      placeholder="Payment Type Name"
                      name="paymentTypeName"
                      className="form-control"
                      value={this.state.paymentTypeName}
                      onChange={this.changePaymentTypeNameHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.updatePaymentType}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default UpdatePaymentTypeComponent;
