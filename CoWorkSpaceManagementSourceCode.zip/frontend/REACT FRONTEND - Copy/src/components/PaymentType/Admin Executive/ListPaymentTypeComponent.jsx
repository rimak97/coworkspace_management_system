import React, { Component } from "react";
import PaymentTypeService from "../../../services/PaymentTypeService";

class ListPaymentTypeComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      paymentTypes: [],
    };
    this.addPaymentType = this.addPaymentType.bind(this);
    this.editPaymentType = this.editPaymentType.bind(this);
    this.deletePaymentType = this.deletePaymentType.bind(this);
  }

  deletePaymentType(id) {
    PaymentTypeService.deletePaymentType(id).then((res) => {
      this.setState({
        paymentTypes: this.state.paymentTypes.filter(
          (paymentType) => paymentType.paymentTypeID !== id
        ),
      });
    });
  }
  viewPaymentType(id) {
    this.props.history.push(`/view-adminExecutivepaymentType/${id}`);
  }
  editPaymentType(id) {
    this.props.history.push(`/add-adminExecutivepaymentType/${id}`);
  }

  componentDidMount() {
    PaymentTypeService.getPaymentTypes().then((res) => {
      this.setState({ paymentTypes: res.data.data });
    });
  }

  addPaymentType() {
    console.log("Add Payment Type Method");
    this.props.history.push("/add-adminExecutivepaymentType/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center text-white">Payment Type List</h1>
        
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> Payment Type Name</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.paymentTypes.map((paymentType) => (
                <tr key={paymentType.paymentTypeID}>
                  <td> {paymentType.paymentTypeName} </td>
                  <td>
                    
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() =>
                        this.viewPaymentType(paymentType.paymentTypeID)
                      }
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListPaymentTypeComponent;
