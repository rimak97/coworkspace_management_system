import React, { Component } from "react";
import homeDashboard from "../Home/HomeNavBar";
import Swal from "sweetalert2";
import UserService from "../../services/UserService";

import { FormErrors } from "./FormErrors";
import "./Form.css";

class CreatePlanComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: "",
      formErrors: { email: "", password: "" },
      emailValid: false,
      passwordValid: false,
      formValid: false,
    };
    this.changeEmailHandler = this.changeEmailHandler.bind(this);
    this.changePasswordHandler = this.changePasswordHandler.bind(this);
  }

  // step 3
  componentDidMount() {}

  changeEmailHandler = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value }, () => {
      this.validateField(name, value);
    });
  };

  changePasswordHandler = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({ [name]: value }, () => {
      this.validateField(name, value);
    });
  };
  HandleSuccess() {
    Swal.fire({
      position: "center",
      icon: "success",
      title: "You have successfully logged in...",
      showConfirmButton: false,
      timer: 1500,
    });
  }

  HandleError() {
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Something went wrong!! Invalid Email ID or Password!!!",

      //footer: '<a href="">Why do I have this issue?</a>'
    });
  }
  loginHandler = (e) => {
    e.preventDefault();
    console.log("Login Handler");
    if (this.state.email.length == 0) {
      alert("Enter Your Email Address");
    } else if (this.state.password.length == 0) {
      alert("Enter Your Password");
    } else {
      let user = { email: this.state.email, password: this.state.password };
      UserService.getUserByEmail(user).then((res) => {
        console.log(res);
        console.log(res.data["status"]);

        if (res.data["status"] == "success") {
          console.log("in sucess");
          const data = res.data["data"];

          sessionStorage["firstName"] = data["firstName"];
          sessionStorage["lastName"] = data["lastName"];
          sessionStorage["token"] = data["token"];
          sessionStorage["roleName"] = data["roleName"];
          sessionStorage["userID"] = data["userID"];
          this.HandleSuccess();
          this.props.history.push("/homeDashBoard");

          // if(sessionStorage['roleName']=='Super Admin')
          // {
          //   this.props.history.push("/homeDashBoard");
          // }else if(sessionStorage['roleName']=='Admin')
          // {
          //   this.props.history.push("/adminDashBoard");
          // }else if(sessionStorage['roleName']=='Executive')
          // {
          //   this.props.history.push("/executiveDashBoard");
          // }else if(sessionStorage['roleName']=='Client')
          // {
          //   this.props.history.push("/clientDashBoard");
          // }else{
          //   this.props.history.push("/homeDashBoard");
          // }
        } else {
          //alert("Invalid User Name or Password!!!")
          this.HandleError();
        }
      });
    }
  };

  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let emailValid = this.state.emailValid;
    let passwordValid = this.state.passwordValid;

    switch (fieldName) {
      case "email":
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
        fieldValidationErrors.email = emailValid ? "" : " is invalid";
        break;
      case "password":
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? "" : " is too short";
        break;
      default:
        break;
    }
    this.setState(
      {
        formErrors: fieldValidationErrors,
        emailValid: emailValid,
        passwordValid: passwordValid,
      },
      this.validateForm
    );
  }

  validateForm() {
    this.setState({
      formValid: this.state.emailValid && this.state.passwordValid,
    });
  }

  errorClass(error) {
    return error.length === 0 ? "" : "has-error";
  }

  cancel() {
    console.log("Go to Home Page");
    this.props.history.push("/");
  }

  render() {
    return (
      <div>
        <homeDashboard />
        <br></br>
        <div className="container">
          <FormErrors formErrors={this.state.formErrors} />

          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> Email ID: </label>
                    <input
                      placeholder="Email ID"
                      name="email"
                      className="form-control"
                      value={this.state.email}
                      onChange={this.changeEmailHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Password: </label>
                    <input
                      placeholder="Password"
                      name="password"
                      className="form-control"
                      value={this.state.password}
                      onChange={this.changePasswordHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success "
                    onClick={this.loginHandler}
                    disabled={!this.state.formValid}
                  >
                    Login
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreatePlanComponent;
