import React, { Component } from "react";
import RoleService from "../../../services/RoleService";

class ListRoleComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      roles: [],
      token: sessionStorage.token,
    };

    console.log(this.state.token);
    this.addRole = this.addRole.bind(this);
    this.editRole = this.editRole.bind(this);
    this.deleteRole = this.deleteRole.bind(this);
  }

  deleteRole(id) {
    RoleService.deleteRole(id).then((res) => {
      this.setState({
        roles: this.state.roles.filter((role) => role.roleID !== id),
      });
    });
  }
  viewRole(id) {
    this.props.history.push(`/view-AdminExecutiverole/${id}`);
  }
  editRole(id) {
    this.props.history.push(`/add-AdminExecutiverole/${id}`);
  }

  componentDidMount() {
    RoleService.getRoles().then((res) => {
      this.setState({ roles: res.data.data });
    });
  }

  addRole() {
    console.log("in addrole");
    this.props.history.push("/add-AdminExecutiverole/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center text-white">Role List</h1>
        
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> Role Name</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.roles.map((role) => (
                <tr key={role.roleID}>
                  <td> {role.roleName} </td>
                  <td>
                    
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewRole(role.roleID)}
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListRoleComponent;
