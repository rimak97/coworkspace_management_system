import React, { Component } from "react";
import RoleService from "../../services/RoleService";

class CreateRoleComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      roleID: this.props.match.params.roleID,
      roleName: "",
    };
    this.changeRoleNameHandler = this.changeRoleNameHandler.bind(this);
    this.saveOrUpdateRole = this.saveOrUpdateRole.bind(this);
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.roleID === "_add") {
      return;
    } else {
      RoleService.getRoleById(this.state.roleID).then((res) => {
        console.log(res.data);
        let role = res.data;
        //console.log(role.data[0].roleName)
        this.setState({ roleName: role.data[0].roleName });
      });
    }
  }
  saveOrUpdateRole = (e) => {
    e.preventDefault();
    let role = { roleName: this.state.roleName };
    console.log("role => " + JSON.stringify(role));

    // step 5
    if (this.state.roleID === "_add") {
      RoleService.createRole(role).then((res) => {
        this.props.history.push("/roles");
      });
    } else {
      RoleService.updateRole(role, this.state.roleID).then((res) => {
        this.props.history.push("/roles");
      });
    }
  };

  changeRoleNameHandler = (event) => {
    console.log("change role handler");
    this.setState({ roleName: event.target.value });
  };

  cancel() {
    this.props.history.push("/roles");
  }

  getTitle() {
    if (this.state.roleID === "_add") {
      return <h3 className="text-center">Add Role</h3>;
    } else {
      return <h3 className="text-center">Update Role</h3>;
    }
  }
  render() {
    return (
      <div>
        <div className="container ">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-header bg-warning">{this.getTitle()}</div>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> Role Name: </label>
                    <input
                      placeholder="Role Name"
                      name="roleName"
                      className="form-control"
                      value={this.state.roleName}
                      onChange={this.changeRoleNameHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdateRole}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateRoleComponent;
