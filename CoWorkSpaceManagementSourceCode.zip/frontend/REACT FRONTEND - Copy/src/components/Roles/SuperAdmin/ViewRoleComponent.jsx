import React, { Component } from "react";
import RoleService from "../../../services/RoleService";

class ViewRoleComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      roleID: this.props.match.params.roleID,
      role: {},
    };
  }

  componentDidMount() {
    RoleService.getRoleById(this.state.roleID).then((res) => {
      console.log(res.data.data[0]);
      this.setState({ role: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/superAdminRoles");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View Role Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> Role Name: </label>
              <div> {this.state.role.roleName}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewRoleComponent;
