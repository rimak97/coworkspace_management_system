import React, { Component } from "react";
import UserService from "../../../services/UserService";
import DropDownRole from "../../../DropDownComponents/DropDownRole";

class CreateUserComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      userID: this.props.match.params.userID,
      password: "",
      roleID: "",
      firstName: "",
      middleName: "",
      lastName: "",
      address: "",
      contactNumber: "",
      email: "",
      aadharCardNumber: "",
    };
    this.changePasswordHandler = this.changePasswordHandler.bind(this);
    this.changeRoleIDHandler = this.changeRoleIDHandler.bind(this);
    this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);
    this.changeMiddleNameHandler = this.changeMiddleNameHandler.bind(this);
    this.changeLastNameHandler = this.changeLastNameHandler.bind(this);
    this.changeAddressHandler = this.changeAddressHandler.bind(this);
    this.changeContactNumberHandler =
      this.changeContactNumberHandler.bind(this);
    this.changeEmailHandler = this.changeEmailHandler.bind(this);
    this.changeAadharCardNumberHandler =
      this.changeAadharCardNumberHandler.bind(this);

    this.saveOrUpdateUser = this.saveOrUpdateUser.bind(this);
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.userID === "_add") {
      return;
    } else {
      UserService.getUserById(this.state.userID).then((res) => {
        let user = res.data;
        this.setState({
          password: user.data[0].password,
          roleID: user.data[0].roleID,
          firstName: user.data[0].firstName,
          middleName: user.data[0].middleName,
          lastName: user.data[0].lastName,
          address: user.data[0].address,
          contactNumber: user.data[0].contactNumber,
          email: user.data[0].email,
          aadharCardNumber: user.data[0].aadharCardNumber,
        });
      });
    }
  }
  saveOrUpdateUser = (e) => {
    e.preventDefault();
    let user = {
      password: this.state.password,
      roleID: this.state.roleID,
      firstName: this.state.firstName,
      middleName: this.state.middleName,
      lastName: this.state.lastName,
      address: this.state.address,
      contactNumber: this.state.contactNumber,
      email: this.state.email,
      aadharCardNumber: this.state.aadharCardNumber,
    };
    console.log("user => " + JSON.stringify(user));

    // step 5
    if (this.state.userID === "_add") {
      UserService.createUser(user).then((res) => {
        this.props.history.push("/clientusers");
      });
    } else {
      UserService.updateUser(user, this.state.userID).then((res) => {
        this.props.history.push("/clientusers");
      });
    }
  };

  changePasswordHandler = (event) => {
    this.setState({ password: event.target.value });
  };

  changeRoleIDHandler = (event) => {
    this.setState({ roleID: event.target.value });
  };

  changeFirstNameHandler = (event) => {
    this.setState({ firstName: event.target.value });
  };

  changeMiddleNameHandler = (event) => {
    this.setState({ middleName: event.target.value });
  };

  changeLastNameHandler = (event) => {
    this.setState({ lastName: event.target.value });
  };

  changeAddressHandler = (event) => {
    this.setState({ address: event.target.value });
  };

  changeContactNumberHandler = (event) => {
    this.setState({ contactNumber: event.target.value });
  };

  changeEmailHandler = (event) => {
    this.setState({ email: event.target.value });
  };

  changeAadharCardNumberHandler = (event) => {
    this.setState({ aadharCardNumber: event.target.value });
  };

  cancel() {
    this.props.history.push("/clientusers");
  }

  getTitle() {
    if (this.state.userID === "_add") {
      return <h3 className="text-center">Add User</h3>;
    } else {
      return <h3 className="text-center">Update User</h3>;
    }
  }

  callbackFunctionForRoleTypeDropDown = (childData) => {
    this.setState({ roleID: childData });
  };

  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-header bg-warning">{this.getTitle()}</div>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> First Name: </label>
                    <input
                      placeholder="First Name"
                      name="firstName"
                      className="form-control"
                      value={this.state.firstName}
                      onChange={this.changeFirstNameHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Middle Name: </label>
                    <input
                      placeholder="Middle Name"
                      name="middleName"
                      className="form-control"
                      value={this.state.middleName}
                      onChange={this.changeMiddleNameHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Last Name: </label>
                    <input
                      placeholder="Last Name"
                      name="lastName"
                      className="form-control"
                      value={this.state.lastName}
                      onChange={this.changeLastNameHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Address: </label>
                    <input
                      placeholder="Address"
                      name="address"
                      className="form-control"
                      value={this.state.address}
                      onChange={this.changeAddressHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Contact Number: </label>
                    <input
                      placeholder="Contact Number"
                      name="contactNumber"
                      className="form-control"
                      value={this.state.contactNumber}
                      onChange={this.changeContactNumberHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Email Id: </label>
                    <input
                      placeholder="Email Address"
                      name="email"
                      className="form-control"
                      value={this.state.email}
                      onChange={this.changeEmailHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Aadhar Card Number: </label>
                    <input
                      placeholder="Aadhar Card Number"
                      name="aadharCardNumber"
                      className="form-control"
                      value={this.state.aadharCardNumber}
                      onChange={this.changeAadharCardNumberHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Password: </label>
                    <input
                      placeholder="Password"
                      name="password"
                      className="form-control"
                      value={this.state.password}
                      onChange={this.changePasswordHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label>
                      {" "}
                      Role :
                      <DropDownRole
                        parentCallback={
                          this.callbackFunctionForRoleTypeDropDown
                        }
                      />
                    </label>
                  </div>

                  {/* <div className="form-group">
                    <label> Role ID: </label>
                    <input
                      placeholder="Role ID"
                      name="roleID"
                      className="form-control"
                      value={this.state.roleID}
                      onChange={this.changeRoleIDHandler}
                    />
                  </div> */}

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdateUser}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateUserComponent;
