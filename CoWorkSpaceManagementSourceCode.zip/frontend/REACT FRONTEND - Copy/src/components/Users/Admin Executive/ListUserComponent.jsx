import React, { Component } from "react";
import UserService from "../../../services/UserService";

class ListUserComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      users: [],
    };
    this.addUser = this.addUser.bind(this);
    this.editUser = this.editUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this);
  }

  deleteUser(userID) {
    UserService.deleteUser(userID).then((res) => {
      this.setState({
        users: this.state.users.filter((user) => user.userID !== userID),
      });
    });
  }
  viewUser(userID) {
    this.props.history.push(`/view-adminExecutiveuser/${userID}`);
  }
  editUser(userID) {
    this.props.history.push(`/add-adminExecutiveuser/${userID}`);
  }

  componentDidMount() {
    UserService.getUsers().then((res) => {
      console.log(res.data.data);
      this.setState({ users: res.data.data });
    });
  }

  addUser() {
    this.props.history.push("/add-adminExecutiveuser/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center text-white">Users List</h1>
        <div className="row">
          <button className="btn btn-primary" onClick={this.addUser}>
            {" "}
            Add User
          </button>
        </div>
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> User First Name</th>
                <th> User Middle Name</th>
                <th> User Last Name</th>
                <th> User Address</th>
                <th> User Contact Number</th>
                <th> User Email Id</th>
                <th> User Aadhar Card Number</th>
                <th> User Role Name</th>
                <th> User Password</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.users.map((user) => (
                <tr key={user.userID}>
                  <td> {user.firstName} </td>
                  <td> {user.middleName} </td>
                  <td> {user.lastName}</td>
                  <td> {user.address}</td>
                  <td> {user.contactNumber}</td>
                  <td> {user.email}</td>
                  <td> {user.aadharCardNumber}</td>
                  <td> {user.roleName}</td>
                  <td> {user.password}</td>

                  <td>
                    <button
                      onClick={() => this.editUser(user.userID)}
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.deleteUser(user.userID)}
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewUser(user.userID)}
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListUserComponent;
