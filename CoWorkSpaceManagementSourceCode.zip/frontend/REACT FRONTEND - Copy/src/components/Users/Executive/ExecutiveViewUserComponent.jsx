import React, { Component } from "react";
import UserService from "../../../services/UserService";

class ViewUserComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      userID: this.props.match.params.userID,
      user: {},
    };
  }

  componentDidMount() {
    UserService.getUserById(this.state.userID).then((res) => {
      //console.log(res.data)
      this.setState({ user: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/ExecuiveListUserComponent");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View User Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> User First Name: </label>
              <div> {this.state.user.firstName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Middle Name: </label>
              <div> {this.state.user.middleName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Last Name: </label>
              <div> {this.state.user.lastName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Address: </label>
              <div> {this.state.user.address}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Contact Number: </label>
              <div> {this.state.user.contactNumber}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Email ID: </label>
              <div> {this.state.user.email}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Aadhar Card Number: </label>
              <div> {this.state.user.aadharCardNumber}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Role Name: </label>
              <div> {this.state.user.roleName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> User Password: </label>
              <div> {this.state.user.password}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewUserComponent;
