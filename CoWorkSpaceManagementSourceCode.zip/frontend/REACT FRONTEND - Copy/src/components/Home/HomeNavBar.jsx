import React, { Component } from "react";
import { Navbar, Nav, Button, Form, Collapse } from "bootstrap-4-react";
import { createBrowserHistory } from "react-router/node_modules/history";

class HomeNavBar extends Component {
  constructor(props) {
    super(props);

    this.logOutHandler = this.logOutHandler.bind(this);
  }

  logOutHandler = (e) => {
    console.log("logout");
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("firstName");
    sessionStorage.removeItem("lastName");
    sessionStorage.removeItem("userID");
    sessionStorage.removeItem("roleName");

    const history = createBrowserHistory({ forceRefresh: true });
    history.push("/login");

    //return <Redirect to='/login'></Redirect>
  };

  signUpHandler = (e) => {
    const history = createBrowserHistory({ forceRefresh: true });
    history.push("/signup");
    //return <Redirect to='/login'></Redirect>
  };

  loginHandler = (e) => {
    const history = createBrowserHistory({ forceRefresh: true });
    history.push("/login");
    //return <Redirect to='/login'></Redirect>
  };

  render() {
    if (sessionStorage.roleName == "Super Admin") {
      return (
        <div>
          <React.Fragment>
            <Navbar expand="lg" dark bg="primary" fixed="top" mb="3">
              <Navbar.Brand href="/homeDashBoard">CoWorkSpace</Navbar.Brand>
              <Navbar.Toggler target="#navbarColor2" />
              <Collapse navbar id="navbarColor2">
                <Navbar.Nav mr="auto">
                  <Nav.ItemLink href="/homeDashBoard" active>
                    <b>Home</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/superAdminRoles" active>
                    <b>Roles</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/superAdminplans" active>
                    <b>Plans</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/superAdminserviceTypes" active>
                    <b>Services</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/superAdminpaymentTypes" active>
                    <b>PaymentTypes</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/superAdmincoworkspaces" active>
                    <b>Coworkspace</b>
                  </Nav.ItemLink>


                  

                  <Nav.ItemLink href="/superAdminusers" active>
                    <b>Users</b>
                  </Nav.ItemLink>


                  



                  
                  
                  <Nav.ItemLink href="/cospaceplanservices" active>
                    <b>CoWorkPlanServices</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/bookings" active>
                    <b>Bookings</b>
                  </Nav.ItemLink>
                </Navbar.Nav>
                <Form inline my="2 lg-0">
                  <h6>
                    <b>
                      Welcome {sessionStorage.firstName} &nbsp; &nbsp; [{" "}
                      {sessionStorage.roleName} ]
                    </b>
                  </h6>
                  &nbsp; &nbsp;
                  <Button
                    outline
                    light
                    my="2 sm-0"
                    onClick={this.logOutHandler}
                  >
                    Logout
                  </Button>
                </Form>
              </Collapse>
            </Navbar>
          </React.Fragment>
        </div>
      );
    } else if (sessionStorage.roleName == "Admin") {
      return (
        <div>
          <React.Fragment>
            <Navbar expand="lg" dark bg="primary" fixed="top" mb="3">
              <Navbar.Brand href="/homeDashBoard">CoWorkSpace</Navbar.Brand>
              <Navbar.Toggler target="#navbarColor2" />
              <Collapse navbar id="navbarColor2">
                <Navbar.Nav mr="auto">
                  <Nav.ItemLink href="/homeDashBoard" active>
                    <b>Home</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutiveRoles" active>
                    <b>Roles</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutiveplans" active>
                    <b>Plans</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutiveserviceTypes" active>
                    <b>Services</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutivepaymentTypes" active>
                    <b>PaymentTypes</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutivecoworkspaces" active>
                    <b>Coworkspace</b>
                  </Nav.ItemLink>


                  <Nav.ItemLink href="/adminExecutiveusers" active>
                    <b>Users</b>
                  </Nav.ItemLink>


                  







                  
                  <Nav.ItemLink href="/cospaceplanservices" active>
                    <b>CoWorkPlanServices</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/bookings" active>
                    <b>Bookings</b>
                  </Nav.ItemLink>
                </Navbar.Nav>
                <Form inline my="2 lg-0">
                  <h6>
                    <b>
                      Welcome {sessionStorage.firstName} &nbsp; &nbsp; [{" "}
                      {sessionStorage.roleName} ]
                    </b>
                  </h6>
                  &nbsp; &nbsp;
                  <Button
                    outline
                    light
                    my="2 sm-0"
                    onClick={this.logOutHandler}
                  >
                    Logout
                  </Button>
                </Form>
              </Collapse>
            </Navbar>
          </React.Fragment>
        </div>
      );
    } else if (sessionStorage.roleName == "Executive") {
      return (
        <div>
          <React.Fragment>
            <Navbar expand="lg" dark bg="primary" fixed="top" mb="3">
              <Navbar.Brand href="/homeDashBoard">CoWorkSpace</Navbar.Brand>
              <Navbar.Toggler target="#navbarColor2" />
              <Collapse navbar id="navbarColor2">
                <Navbar.Nav mr="auto">
                  <Nav.ItemLink href="/homeDashBoard" active>
                    <b>Home</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/adminExecutiveRoles" active>
                    <b>Roles</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutiveplans" active>
                    <b>Plans</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutiveserviceTypes" active>
                    <b>Services</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/adminExecutivepaymentTypes" active>
                    <b>PaymentTypes</b>
                  </Nav.ItemLink>


                  <Nav.ItemLink href="/executivecoworkspaces" active>
                    <b>Coworkspace</b>
                  </Nav.ItemLink>


                  <Nav.ItemLink href="/adminExecutiveusers" active>
                    <b>Users</b>
                  </Nav.ItemLink>


                  




                  
                  <Nav.ItemLink href="/cospaceplanservices" active>
                    <b>CoWorkPlanServices</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/bookings" active>
                    <b>Bookings</b>
                  </Nav.ItemLink>
                </Navbar.Nav>
                <Form inline my="2 lg-0">
                  <h6>
                    <b>
                      Welcome {sessionStorage.firstName} &nbsp; &nbsp; [{" "}
                      {sessionStorage.roleName} ]
                    </b>
                  </h6>
                  &nbsp; &nbsp;
                  <Button
                    outline
                    light
                    my="2 sm-0"
                    onClick={this.logOutHandler}
                  >
                    Logout
                  </Button>
                </Form>
              </Collapse>
            </Navbar>
          </React.Fragment>
        </div>
      );
    } else if (sessionStorage.roleName == "Client") {
      return (
        <div>
          <React.Fragment>
            <Navbar expand="lg" dark bg="primary" fixed="top" mb="3">
              <Navbar.Brand href="/homeDashBoard">CoWorkSpace</Navbar.Brand>
              <Navbar.Toggler target="#navbarColor2" />
              <Collapse navbar id="navbarColor2">
                <Navbar.Nav mr="auto">
                  <Nav.ItemLink href="/homeDashBoard" active>
                    <b>Home</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/clientcoworkspaces" active>
                    <b>Coworkspace</b>
                  </Nav.ItemLink>


                  <Nav.ItemLink href="/clientusers" active>
                    <b>Clients</b>
                  </Nav.ItemLink>






                  

                  <Nav.ItemLink href="/ClientListCoSpacePlanService" active>
                    <b>CoWorkPlanServices</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/bookings" active>
                    <b>Bookings</b>
                  </Nav.ItemLink>
                </Navbar.Nav>
                <Form inline my="2 lg-0">
                  <h6>
                    <b>
                      Welcome {sessionStorage.firstName} &nbsp; &nbsp; [{" "}
                      {sessionStorage.roleName} ]
                    </b>
                  </h6>
                  &nbsp; &nbsp;
                  <Button
                    outline
                    light
                    my="2 sm-0"
                    onClick={this.logOutHandler}
                  >
                    Logout
                  </Button>
                </Form>
              </Collapse>
            </Navbar>
          </React.Fragment>
        </div>
      );
    } else {
      return (
        <div>
          <React.Fragment>
            <Navbar expand="lg" dark bg="primary" fixed="top" mb="3">
              <Navbar.Brand href="/homeDashBoard">CoWorkSpace</Navbar.Brand>
              <Navbar.Toggler target="#navbarColor2" />
              <Collapse navbar id="navbarColor2">
                <Navbar.Nav mr="auto">
                  <Nav.ItemLink href="/homeDashBoard" active>
                    <b>Home</b>
                  </Nav.ItemLink>

                  <Nav.ItemLink href="/about" active>
                    <b>About Us</b>
                  </Nav.ItemLink>
                  <Nav.ItemLink href="/contact" active>
                    <b>Contact Us</b>
                  </Nav.ItemLink>
                </Navbar.Nav>
                <Form inline my="2 lg-0">
                  <Button outline light my="2 sm-0" onClick={this.loginHandler}>
                    Login
                  </Button>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <Button
                    outline
                    light
                    my="2 sm-0"
                    onClick={this.signUpHandler}
                  >
                    Sign Up
                  </Button>
                </Form>
              </Collapse>
            </Navbar>
          </React.Fragment>
        </div>
      );
    }
  }
}

export default HomeNavBar;
