import React, { Component } from "react";
import CoWorkSpaceService from "../../services/CoWorkSpaceService";

class View1CoWorkSpaceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      coworkID: this.props.match.params.coworkID,
      coworkspace: {},
    };
  }

  componentDidMount() {
    CoWorkSpaceService.getCoWorkSpaceById(this.state.coworkID).then((res) => {
      console.log(res.data.data[0]);
      this.setState({ coworkspace: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/coworkspaces");
  }

  render() {
    return (
      <div>
        <h3 className="text-center"> View CoworkSpace Details</h3>

        <table className="table table-dark table-bordered table-hover ">
          <tbody>
            <tr>
              <td> CoworkSpace Name </td>
              <td> {this.state.coworkspace.coworkName}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default View1CoWorkSpaceComponent;
