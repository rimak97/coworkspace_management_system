import React, { Component } from "react";
import CoWorkSpaceService from "../../services/CoWorkSpaceService";

class CreateCoWorkSpaceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      coworkID: this.props.match.params.coworkID,
      coworkName: "",
      address: "",
      contactNumber: "",
      email: "",
      website: "",
    };

    this.changeCoworkNameHandler = this.changeCoworkNameHandler.bind(this);
    this.changeAddressHandler = this.changeAddressHandler.bind(this);
    this.changeContactNumberHandler =
      this.changeContactNumberHandler.bind(this);
    this.changeEmailHandler = this.changeEmailHandler.bind(this);
    this.changeWebsiteHandler = this.changeWebsiteHandler.bind(this);

    this.saveOrUpdateCoWorkSpace = this.saveOrUpdateCoWorkSpace.bind(this);
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.coworkID === "_add") {
      return;
    } else {
      CoWorkSpaceService.getCoWorkSpaceById(this.state.coworkID).then((res) => {
        let coworkspace = res.data;
        this.setState({
          coworkName: coworkspace.data[0].coworkName,
          address: coworkspace.data[0].address,
          contactNumber: coworkspace.data[0].contactNumber,
          email: coworkspace.data[0].email,
          website: coworkspace.data[0].website,
        });
      });
    }
  }
  saveOrUpdateCoWorkSpace = (e) => {
    e.preventDefault();
    let coworkspace = {
      coworkName: this.state.coworkName,
      address: this.state.address,
      contactNumber: this.state.contactNumber,
      email: this.state.email,
      website: this.state.website,
    };
    console.log("coworkspace => " + JSON.stringify(coworkspace));

    // step 5
    if (this.state.coworkID === "_add") {
      CoWorkSpaceService.createCoWorkSpace(coworkspace).then((res) => {
        this.props.history.push("/coworkspaces");
      });
    } else {
      CoWorkSpaceService.updateCoWorkSpace(
        coworkspace,
        this.state.coworkID
      ).then((res) => {
        this.props.history.push("/coworkspaces");
      });
    }
  };

  changeCoworkNameHandler = (event) => {
    this.setState({ coworkName: event.target.value });
  };

  changeAddressHandler = (event) => {
    this.setState({ address: event.target.value });
  };

  changeContactNumberHandler = (event) => {
    this.setState({ contactNumber: event.target.value });
  };

  changeEmailHandler = (event) => {
    this.setState({ email: event.target.value });
  };

  changeWebsiteHandler = (event) => {
    this.setState({ website: event.target.value });
  };

  cancel() {
    this.props.history.push("/coworkspaces");
  }

  getTitle() {
    if (this.state.coworkID === "_add") {
      return <h3 className="text-center">Add CoWorkSpace</h3>;
    } else {
      return <h3 className="text-center">Update CoWorkSpace</h3>;
    }
  }
  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-header bg-warning">{this.getTitle()}</div>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> CoWorkSpace Name: </label>
                    <input
                      placeholder="CoWorkSpace Name"
                      name="coworkName"
                      className="form-control"
                      value={this.state.coworkName}
                      onChange={this.changeCoworkNameHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Address: </label>
                    <input
                      placeholder="Address"
                      name="address"
                      className="form-control"
                      value={this.state.address}
                      onChange={this.changeAddressHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Contact Number: </label>
                    <input
                      placeholder="Contact Number"
                      name="contactNumber"
                      className="form-control"
                      value={this.state.contactNumber}
                      onChange={this.changeContactNumberHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Email Id: </label>
                    <input
                      placeholder="Email Address"
                      name="email"
                      className="form-control"
                      value={this.state.email}
                      onChange={this.changeEmailHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Website: </label>
                    <input
                      placeholder="Website"
                      name="website"
                      className="form-control"
                      value={this.state.middleName}
                      onChange={this.changeWebsiteHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdateCoWorkSpace}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateCoWorkSpaceComponent;
