import React, { Component } from "react";
import CoWorkSpaceService from "../../../services/CoWorkSpaceService";

class ViewCoWorkSpaceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      coworkID: this.props.match.params.coworkID,
      coworkspace: {},
    };
  }

  componentDidMount() {
    CoWorkSpaceService.getCoWorkSpaceById(this.state.coworkID).then((res) => {
      console.log(res.data.data[0]);
      this.setState({ coworkspace: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/executivecoworkspaces");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View CoworkSpace Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> CoworkSpace Name: </label>
              <div> {this.state.coworkspace.coworkName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> CoworkSpace Address: </label>
              <div> {this.state.coworkspace.address}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> CoworkSpace Contact Number: </label>
              <div> {this.state.coworkspace.contactNumber}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> CoworkSpace Email ID: </label>
              <div> {this.state.coworkspace.email}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> CoworkSpace Website: </label>
              <div> {this.state.coworkspace.website}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewCoWorkSpaceComponent;
