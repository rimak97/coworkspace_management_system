import React, { Component } from "react";
import CoWorkSpaceService from "../../../services/CoWorkSpaceService";

class ListCoWorkSpaceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      coworkspaces: [],
      token: sessionStorage.token,
    };
    this.addCoWorkSpace = this.addCoWorkSpace.bind(this);
    this.editCoWorkSpace = this.editCoWorkSpace.bind(this);
    this.deleteCoWorkSpace = this.deleteCoWorkSpace.bind(this);
  }

  deleteCoWorkSpace(coworkID) {
    CoWorkSpaceService.deleteCoWorkSpace(coworkID).then((res) => {
      this.setState({
        coworkspaces: this.state.coworkspaces.filter(
          (coworkspace) => coworkspace.coworkID !== coworkID
        ),
      });
    });
  }
  viewCoWorkSpace(coworkID) {
    this.props.history.push(`/view-superAdmincoworkspace/${coworkID}`);
  }
  editCoWorkSpace(coworkID) {
    this.props.history.push(`/add-superAdmincoworkspace/${coworkID}`);
  }

  componentDidMount() {
    CoWorkSpaceService.getCoWorkSpaces().then((res) => {
      this.setState({ coworkspaces: res.data.data });
    });
  }

  addCoWorkSpace() {
    this.props.history.push("/add-superAdmincoworkspace/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center" text-white>
          CoWorkSpaces List
        </h1>
        <div className="row">
          <button className="btn btn-primary" onClick={this.addCoWorkSpace}>
            {" "}
            Add CoWorkSpace
          </button>
        </div>
        
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> CoWorkSpace Name</th>
                <th> CoWorkSpace Address</th>
                <th> CoWorkSpace Contact Number</th>
                <th> CoWorkSpace Email Id</th>
                <th> CoWorkSpace Website</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.coworkspaces.map((coworkspace) => (
                <tr key={coworkspace.coworkID}>
                  <td> {coworkspace.coworkName} </td>
                  <td> {coworkspace.address}</td>
                  <td> {coworkspace.contactNumber}</td>
                  <td> {coworkspace.email}</td>
                  <td> {coworkspace.website} </td>

                  <td>
                    <button
                      onClick={() => this.editCoWorkSpace(coworkspace.coworkID)}
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>

                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() =>
                        this.deleteCoWorkSpace(coworkspace.coworkID)
                      }
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewCoWorkSpace(coworkspace.coworkID)}
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListCoWorkSpaceComponent;
