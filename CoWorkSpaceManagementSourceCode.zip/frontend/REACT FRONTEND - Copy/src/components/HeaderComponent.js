// import React, { Component } from "react";
// import { Link } from "react-router-dom";


// class HeaderComponent extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {};
//   }

//   render() {
//     return (
//       <div>
//         <header>
//           <nav className="navbar navbar-expand-md navbar-dark bg-dark">
//             <div>
//               <a href="http://localhost:3000/" className="navbar-brand">
//                 CoWork Space Management System
//               </a>
              
//               <Link to="/about">About</Link>{"      "}
//               <Link to="/roles">Roles</Link>{"      "}
//               <Link to="/plans">Plans</Link>{"      "}
//               <Link to="/serviceTypes">ServiceTypes</Link>{"      "}
//               <Link to="/paymentTypes">PaymentTypes</Link>{"      "}
//               <Link to="/users">Users</Link>{"      "}
//               <Link to="/coworkspaces">CoWorkSpaces</Link>{"      "}
//               <Link to="/cospaceplanservices">CoSpacePlanService</Link>{"      "}
//               <Link to="/bookings">Bookings</Link>{"      "}
//               <Link to="/login">Login</Link>{"      "}
//               <Link to="/DropDown">DropDown</Link>
//             </div>
//           </nav>
//         </header>
//       </div>
//     );
//   }
// }

// export default HeaderComponent;



