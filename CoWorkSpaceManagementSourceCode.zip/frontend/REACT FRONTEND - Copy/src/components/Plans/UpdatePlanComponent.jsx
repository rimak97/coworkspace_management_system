import React, { Component } from "react";
import PlanService from "../../services/PlanService";

class UpdatePlanComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      planTypeID: this.props.match.params.planTypeID,
      planName: "",
    };
    this.changePlanNameHandler = this.changePlanNameHandler.bind(this);

    this.updatePlan = this.updatePlan.bind(this);
  }

  componentDidMount() {
    PlanService.getPlanById(this.state.planTypeID).then((res) => {
      let plan = res.data;
      this.setState({ planName: plan.planName });
    });
  }

  updatePlan = (e) => {
    e.preventDefault();
    let plan = { planName: this.state.planName };
    console.log("plan => " + JSON.stringify(plan));
    console.log("id => " + JSON.stringify(this.state.planTypeID));
    PlanService.updatePlan(plan, this.state.planTypeID).then((res) => {
      this.props.history.push("/plans");
    });
  };

  changePlanNameHandler = (event) => {
    this.setState({ planName: event.target.value });
  };

  cancel() {
    this.props.history.push("/plans");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-center">Update Plan</h3>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> plan Name: </label>
                    <input
                      placeholder="plan Name"
                      name="planName"
                      className="form-control"
                      value={this.state.planName}
                      onChange={this.changePlanNameHandler}
                    />
                  </div>

                  <button className="btn btn-success" onClick={this.updatePlan}>
                    Save
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default UpdatePlanComponent;
