import React, { Component } from "react";
import PlanService from "../../../services/PlanService";

class ViewPlanComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      planTypeID: this.props.match.params.planTypeID,
      plan: {},
    };
  }

  componentDidMount() {
    PlanService.getPlanById(this.state.planTypeID).then((res) => {
      console.log(res.data.data[0]);
      this.setState({ plan: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/superAdminplans");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View Plan Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> Plan Name: </label>
              <div> {this.state.plan.planName}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewPlanComponent;
