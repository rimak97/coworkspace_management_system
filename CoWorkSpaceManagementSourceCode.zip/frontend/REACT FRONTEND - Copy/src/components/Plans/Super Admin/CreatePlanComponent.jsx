import React, { Component } from "react";
import PlanService from "../../../services/PlanService";

class CreatePlanComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      planTypeID: this.props.match.params.planTypeID,
      planName: "",
    };
    this.changePlanNameHandler = this.changePlanNameHandler.bind(this);
    this.saveOrUpdatePlan = this.saveOrUpdatePlan.bind(this);
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.planTypeID === "_add") {
      return;
    } else {
      PlanService.getPlanById(this.state.planTypeID).then((res) => {
        console.log(res.data);
        let plan = res.data;
        //console.log(plan.data[0].planName)
        this.setState({ planName: plan.data[0].planName });
      });
    }
  }
  saveOrUpdatePlan = (e) => {
    e.preventDefault();
    let plan = { planName: this.state.planName };
    console.log("plan => " + JSON.stringify(plan));

    // step 5
    if (this.state.planTypeID === "_add") {
      PlanService.createPlan(plan).then((res) => {
        this.props.history.push("/superAdminplans");
      });
    } else {
      PlanService.updatePlan(plan, this.state.planTypeID).then((res) => {
        this.props.history.push("/superAdminplans");
      });
    }
  };

  changePlanNameHandler = (event) => {
    console.log("change plan handler");
    this.setState({ planName: event.target.value });
  };

  cancel() {
    this.props.history.push("/superAdminplans");
  }

  getTitle() {
    if (this.state.planTypeID === "_add") {
      return <h3 className="text-center">Add Plan</h3>;
    } else {
      return <h3 className="text-center">Update plan</h3>;
    }
  }
  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <div className="card-header bg-warning">{this.getTitle()}</div>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> Plan Name: </label>
                    <input
                      placeholder="Plan Name"
                      name="planName"
                      className="form-control"
                      value={this.state.planName}
                      onChange={this.changePlanNameHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdatePlan}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreatePlanComponent;
