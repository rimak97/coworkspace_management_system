import React, { Component } from "react";
import PlanService from "../../../services/PlanService";

class ListPlanComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      plans: [],
    };
    this.addPlan = this.addPlan.bind(this);
    this.editPlan = this.editPlan.bind(this);
    this.deletePlan = this.deletePlan.bind(this);
  }

  deletePlan(id) {
    PlanService.deletePlan(id).then((res) => {
      this.setState({
        plans: this.state.plans.filter((plan) => plan.planTypeID !== id),
      });
    });
  }
  viewPlan(id) {
    this.props.history.push(`/view-adminExecutiveplan/${id}`);
  }
  editPlan(id) {
    this.props.history.push(`/add-adminExecutiveplan/${id}`);
  }

  componentDidMount() {
    PlanService.getPlans().then((res) => {
      this.setState({ plans: res.data.data });
    });
  }

  addPlan() {
    console.log("in addplan");
    this.props.history.push("/add-adminExecutiveplan/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center text-white">Plan List</h1>
        
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> Plan Name</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.plans.map((plan) => (
                <tr key={plan.planTypeID}>
                  <td> {plan.planName} </td>
                  <td>
                    
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewPlan(plan.planTypeID)}
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListPlanComponent;
