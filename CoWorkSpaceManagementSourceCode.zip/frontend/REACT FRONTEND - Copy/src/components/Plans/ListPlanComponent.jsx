import React, { Component } from "react";
import PlanService from "../../services/PlanService";

class ListPlanComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      plans: [],
    };
    this.addPlan = this.addPlan.bind(this);
    this.editPlan = this.editPlan.bind(this);
    this.deletePlan = this.deletePlan.bind(this);
  }

  deletePlan(id) {
    PlanService.deletePlan(id).then((res) => {
      this.setState({
        plans: this.state.plans.filter((plan) => plan.planTypeID !== id),
      });
    });
  }
  viewPlan(id) {
    this.props.history.push(`/view-plan/${id}`);
  }
  editPlan(id) {
    this.props.history.push(`/add-plan/${id}`);
  }

  componentDidMount() {
    PlanService.getPlans().then((res) => {
      this.setState({ plans: res.data.data });
    });
  }

  addPlan() {
    console.log("in addplan");
    this.props.history.push("/add-plan/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center text-white">Plan List</h1>
        <div className="row">
          <button className="btn btn-primary" onClick={this.addPlan}>
            {" "}
            Add Plan
          </button>
        </div>
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> Plan Name</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.plans.map((plan) => (
                <tr key={plan.planTypeID}>
                  <td> {plan.planName} </td>
                  <td>
                    <button
                      onClick={() => this.editPlan(plan.planTypeID)}
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.deletePlan(plan.planTypeID)}
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() => this.viewPlan(plan.planTypeID)}
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListPlanComponent;
