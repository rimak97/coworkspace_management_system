import React, { Component } from "react";
import ServiceTypeService from "../../../services/ServiceTypeService";

class ListServiceTypeComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      serviceTypes: [],
    };
    this.addServiceType = this.addServiceType.bind(this);
    this.editServiceType = this.editServiceType.bind(this);
    this.deleteServiceType = this.deleteServiceType.bind(this);
  }

  deleteServiceType(id) {
    ServiceTypeService.deleteServiceType(id).then((res) => {
      this.setState({
        serviceTypes: this.state.serviceTypes.filter(
          (serviceType) => serviceType.serviceTypeID !== id
        ),
      });
    });
  }
  viewServiceType(id) {
    this.props.history.push(`/view-superAdminserviceType/${id}`);
  }
  editServiceType(id) {
    this.props.history.push(`/add-superAdminserviceType/${id}`);
  }

  componentDidMount() {
    ServiceTypeService.getServiceTypes().then((res) => {
      this.setState({ serviceTypes: res.data.data });
    });
  }

  addServiceType() {
    console.log("in addServiceType");
    this.props.history.push("/add-superAdminserviceType/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center">Service Type List</h1>
        <div className="row">
          <button className="btn btn-primary" onClick={this.addServiceType}>
            {" "}
            Add Service Type
          </button>
        </div>
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead className="thead-dark">
              <tr>
                <th> Service Type Name</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.serviceTypes.map((serviceType) => (
                <tr key={serviceType.serviceTypeID}>
                  <td> {serviceType.serviceTypeName} </td>
                  <td>
                    <button
                      onClick={() =>
                        this.editServiceType(serviceType.serviceTypeID)
                      }
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() =>
                        this.deleteServiceType(serviceType.serviceTypeID)
                      }
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() =>
                        this.viewServiceType(serviceType.serviceTypeID)
                      }
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListServiceTypeComponent;
