import React, { Component } from "react";
import ServiceTypeService from "../../services/ServiceTypeService";

class UpdateServiceTypeComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      serviceTypeID: this.props.match.params.serviceTypeID,
      serviceTypeName: "",
    };
    this.changeServiceTypeNameHandler =
      this.changeServiceTypeNameHandler.bind(this);

    this.updateServiceType = this.updateServiceType.bind(this);
  }

  componentDidMount() {
    ServiceTypeService.getServiceTypeById(this.state.serviceTypeID).then(
      (res) => {
        let serviceType = res.data;
        this.setState({ serviceTypeName: serviceType.serviceTypeName });
      }
    );
  }

  updateServiceType = (e) => {
    e.preventDefault();
    let serviceType = { serviceTypeName: this.state.serviceTypeName };
    console.log("serviceType => " + JSON.stringify(serviceType));
    console.log("id => " + JSON.stringify(this.state.serviceTypeID));
    ServiceTypeService.updateServiceType(
      serviceType,
      this.state.serviceTypeID
    ).then((res) => {
      this.props.history.push("/serviceTypes");
    });
  };

  changeServiceTypeNameHandler = (event) => {
    this.setState({ serviceTypeName: event.target.value });
  };

  cancel() {
    this.props.history.push("/serviceTypes");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="container">
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-center">Update Service Type</h3>
              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label> Service Type Name: </label>
                    <input
                      placeholder="Service Type Name"
                      name="serviceTypeName"
                      className="form-control"
                      value={this.state.serviceTypeName}
                      onChange={this.changeServiceTypeNameHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.updateServiceType}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default UpdateServiceTypeComponent;
