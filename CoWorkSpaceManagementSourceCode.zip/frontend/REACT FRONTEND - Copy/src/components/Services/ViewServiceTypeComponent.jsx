import React, { Component } from "react";
import ServiceTypeService from "../../services/ServiceTypeService";

class ViewServiceTypeComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      serviceTypeID: this.props.match.params.serviceTypeID,
      serviceType: {},
    };
  }

  componentDidMount() {
    ServiceTypeService.getServiceTypeById(this.state.serviceTypeID).then(
      (res) => {
        console.log(res.data.data[0]);
        this.setState({ serviceType: res.data.data[0] });
      }
    );
  }

  cancel() {
    this.props.history.push("/serviceTypes");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View Service Type Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> Service Type Name : </label>
              &nbsp;&nbsp;<div> {this.state.serviceType.serviceTypeName}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ViewServiceTypeComponent;
