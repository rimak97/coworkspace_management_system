import React, { Component } from "react";
import CoSpacePlanServiceService from "../../../services/CoSpacePlanServiceService";
import PlanService from "../../../services/PlanService";
import DropDownCoSpace from "../../../../DropDownComponents/DropDownCoSpace";
import DropDownServiceType from "../../../DropDownComponents/DropDownServiceType";
import DropDownPlanType from "../../../DropDownComponents/DropDownPlanType";

class CreateCoSpacePlanServiceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // step 2
      billingID: this.props.match.params.billingID,
      coworkID: "",
      serviceTypeID: "",
      planTypeID: "",
      rate: "",
      discount: "",
      gst: "",
      actQty: "",

      plans: [],
    };

    this.changeCoworkIDHandler = this.changeCoworkIDHandler.bind(this);
    this.changeServiceTypeIDHandler =
      this.changeServiceTypeIDHandler.bind(this);
    this.changePlanTypeIDHandler = this.changePlanTypeIDHandler.bind(this);
    this.changeRateHandler = this.changeRateHandler.bind(this);
    this.changeDiscountHandler = this.changeDiscountHandler.bind(this);
    this.changeGstHandler = this.changeGstHandler.bind(this);
    this.changeActQtyHandler = this.changeActQtyHandler.bind(this);
    this.changePlansDropDownHandler =
      this.changePlansDropDownHandler.bind(this);

    this.saveOrUpdateCoSpacePlanService =
      this.saveOrUpdateCoSpacePlanService.bind(this);
  }

  async getOptions() {
    PlanService.getPlans().then((res) => {
      // this.setState({ plans: res.data.data});
      console.log(res.data.data);

      const options = res.data.data.map((d) => ({
        value: d.planTypeID,
        display: d.planName,
      }));

      console.log(options);
      //this.setState({plans: options})
      this.setState({
        plans: [{ value: "", display: "(Select your favourite team)" }].concat(
          options
        ),
      });
      console.log(this.state.plans);
    });
  }

  // step 3
  componentDidMount() {
    // step 4
    if (this.state.billingID === "_add") {
      this.getOptions();
      return;
    } else {
      CoSpacePlanServiceService.getCoSpacePlanServiceById(
        this.state.billingID
      ).then((res) => {
        let cospaceplanservice = res.data;
        this.setState({
          coworkID: cospaceplanservice.data[0].coworkID,
          serviceTypeID: cospaceplanservice.data[0].serviceTypeID,
          planTypeID: cospaceplanservice.data[0].planTypeID,
          rate: cospaceplanservice.data[0].rate,
          discount: cospaceplanservice.data[0].discount,
          gst: cospaceplanservice.data[0].gst,
          actQty: cospaceplanservice.data[0].actQty,
        });
      });
    }
  }
  saveOrUpdateCoSpacePlanService = (e) => {
    e.preventDefault();
    let cospaceplanservice = {
      coworkID: this.state.coworkID,
      serviceTypeID: this.state.serviceTypeID,
      planTypeID: this.state.planTypeID,
      rate: this.state.rate,
      discount: this.state.discount,
      gst: this.state.gst,
      actQty: this.state.actQty,
    };
    console.log("cospaceplanservice => " + JSON.stringify(cospaceplanservice));

    // step 5
    if (this.state.billingID === "_add") {
      console.log("Billing ID:" + this.state.billingID);
      console.log(cospaceplanservice);
      CoSpacePlanServiceService.createCoSpacePlanService(
        cospaceplanservice
      ).then((res) => {
        console.log(res);
        this.props.history.push("/superAdmincospaceplanservices");
      });
    } else {
      console.log("Billing ID:" + this.state.billingID);
      console.log(cospaceplanservice);
      CoSpacePlanServiceService.updateCoSpacePlanService(
        cospaceplanservice,
        this.state.billingID
      ).then((res) => {
        console.log(res.data);
        this.props.history.push("/superAdmincospaceplanservices");
      });
    }
  };

  changePlansDropDownHandler = (e) => {
    e.preventDefault();
    this.setState({
      selectedPlanTypeID: e.target.value,
      selectedPlanName: e.target.display,
    });
  };

  changeCoworkIDHandler = (event) => {
    this.setState({ coworkID: event.target.value });
  };

  changeServiceTypeIDHandler = (event) => {
    this.setState({ serviceTypeID: event.target.value });
  };

  changePlanTypeIDHandler = (event) => {
    this.setState({ planTypeID: event.target.value });
  };

  changeRateHandler = (event) => {
    this.setState({ rate: event.target.value });
  };

  changeDiscountHandler = (event) => {
    this.setState({ discount: event.target.value });
  };

  changeGstHandler = (event) => {
    this.setState({ gst: event.target.value });
  };

  changeActQtyHandler = (event) => {
    this.setState({ actQty: event.target.value });
  };

  cancel() {
    this.props.history.push("/superAdmincospaceplanservices");
  }

  getTitle() {
    if (this.state.billingID === "_add") {
      return (
        <h5 className="text-center">Add Cowork Space Plan &amp; Service </h5>
      );
    } else {
      return (
        <h5 className="text-center">Update Cowork Space Plan &amp; Service </h5>
      );
    }
  }

  callbackFunctionForPlanTypeDropDown = (childData) => {
    this.setState({ planTypeID: childData });
  };

  callbackFunctionForCoSpaceDropDown = (childData) => {
    this.setState({ coworkID: childData });
  };

  callbackFunctionForServiceTypeDropDown = (childData) => {
    this.setState({ serviceTypeID: childData });
  };

  render() {
    console.log("map:");
    console.log(this.state.plans);
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="card col-md-8 offset-md-3 offset-md-3 ">
              <div className="card-header bg-warning">{this.getTitle()}</div>

              <div className="card-body">
                <form>
                  <div className="form-group">
                    <label>
                      {" "}
                      CoWork Space Name:
                      <DropDownCoSpace
                        parentCallback={this.callbackFunctionForCoSpaceDropDown}
                      />
                    </label>
                  </div>

                  <div className="form-group">
                    <label>
                      {" "}
                      Service Type:
                      <DropDownServiceType
                        parentCallback={
                          this.callbackFunctionForServiceTypeDropDown
                        }
                      />
                    </label>
                  </div>

                  <div className="form-group">
                    <label>
                      {" "}
                      Plan Type:
                      <DropDownPlanType
                        parentCallback={
                          this.callbackFunctionForPlanTypeDropDown
                        }
                      />
                    </label>
                  </div>

                  {/* <div className="form-group">
                    <label> CoWork Space ID: </label>
                    <input
                      placeholder="Cowork Space ID"
                      name="coworkID"
                      className="form-control"
                      value={this.state.coworkID}
                      onChange={this.changeCoworkIDHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Service Type ID: </label>
                    <input
                      placeholder="Service Type ID"
                      name="serviceTypeID"
                      className="form-control"
                      value={this.state.serviceTypeID}
                      onChange={this.changeServiceTypeIDHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Plan Type ID: </label>
                    <input
                      placeholder="Plan Type ID"
                      name="planTypeID"
                      className="form-control"
                      value={this.state.planTypeID}
                      onChange={this.changePlanTypeIDHandler}
                    />
                  </div> */}

                  <div className="form-group">
                    <label> Rate: </label>
                    <input
                      placeholder="Rate"
                      name="rate"
                      className="form-control"
                      value={this.state.rate}
                      onChange={this.changeRateHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Discount: </label>
                    <input
                      placeholder="Discount"
                      name="discount"
                      className="form-control"
                      value={this.state.discount}
                      onChange={this.changeDiscountHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> GST: </label>
                    <input
                      placeholder="GST"
                      name="gst"
                      className="form-control"
                      value={this.state.gst}
                      onChange={this.changeGstHandler}
                    />
                  </div>

                  <div className="form-group">
                    <label> Actual Qty: </label>
                    <input
                      placeholder="Actual Qty"
                      name="actQty"
                      className="form-control"
                      value={this.state.actQty}
                      onChange={this.changeActQtyHandler}
                    />
                  </div>

                  <button
                    className="btn btn-success"
                    onClick={this.saveOrUpdateCoSpacePlanService}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CreateCoSpacePlanServiceComponent;
