import React, { Component } from "react";
import CoSpacePlanServiceService from "../../../services/CoSpacePlanServiceService";

class ListCoSpacePlanServiceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      cospaceplanservices: [],
    };
    this.addCoSpacePlanService = this.addCoSpacePlanService.bind(this);
    this.editCoSpacePlanService = this.editCoSpacePlanService.bind(this);
    this.deleteCoSpacePlanService = this.deleteCoSpacePlanService.bind(this);
  }

  deleteCoSpacePlanService(billingID) {
    CoSpacePlanServiceService.deleteCoSpacePlanService(billingID).then(
      (res) => {
        this.setState({
          cospaceplanservices: this.state.cospaceplanservices.filter(
            (cospaceplanservice) => cospaceplanservice.billingID !== billingID
          ),
        });
      }
    );
  }
  viewCoSpacePlanService(billingID) {
    this.props.history.push(`/view-cospaceplanservice/${billingID}`);
  }
  editCoSpacePlanService(billingID) {
    this.props.history.push(`/add-cospaceplanservice/${billingID}`);
  }

  componentDidMount() {
    CoSpacePlanServiceService.getCoSpacePlanServices().then((res) => {
      this.setState({ cospaceplanservices: res.data.data });
    });
  }

  addCoSpacePlanService() {
    this.props.history.push("/add-cospaceplanservice/_add");
  }

  render() {
    return (
      <div>
        <h1 className="text-center text-white">CoSpacePlanServices List</h1>
        <div className="row">
          <button
            className="btn btn-primary"
            onClick={this.addCoSpacePlanService}
          >
            {" "}
            Add CoSpacePlanService
          </button>
        </div>
        <br></br>
        <div className="row">
          <table className="table table-dark table-bordered table-hover">
            <thead>
              <tr>
                <th> CoWorkSpace Name</th>
                <th> Service Type</th>
                <th> Plan Type</th>
                <th> Rate</th>
                <th> Discount</th>
                <th> GST</th>
                <th> Actual Qty</th>
                <th> Actions</th>
              </tr>
            </thead>
            <tbody>
              {this.state.cospaceplanservices.map((cospaceplanservice) => (
                <tr key={cospaceplanservice.billingID}>
                  <td> {cospaceplanservice.coworkName} </td>
                  <td> {cospaceplanservice.serviceTypeName} </td>
                  <td> {cospaceplanservice.planName}</td>
                  <td> {cospaceplanservice.rate}</td>
                  <td> {cospaceplanservice.discount}</td>
                  <td> {cospaceplanservice.gst}</td>
                  <td> {cospaceplanservice.actQty}</td>

                  <td>
                    <button
                      onClick={() =>
                        this.editCoSpacePlanService(
                          cospaceplanservice.billingID
                        )
                      }
                      className="btn btn-info"
                    >
                      Update{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() =>
                        this.deleteCoSpacePlanService(
                          cospaceplanservice.billingID
                        )
                      }
                      className="btn btn-danger"
                    >
                      Delete{" "}
                    </button>
                    <button
                      style={{ marginLeft: "10px" }}
                      onClick={() =>
                        this.viewCoSpacePlanService(
                          cospaceplanservice.billingID
                        )
                      }
                      className="btn btn-primary"
                    >
                      View{" "}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListCoSpacePlanServiceComponent;
