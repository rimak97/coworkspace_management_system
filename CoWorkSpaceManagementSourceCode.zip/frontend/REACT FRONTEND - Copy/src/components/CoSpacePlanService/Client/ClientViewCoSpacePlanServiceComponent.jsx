import React, { Component } from "react";
import CoSpacePlanServiceService from "../../services/CoSpacePlanServiceService";

class ClientViewCoSpacePlanServiceComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      billingID: this.props.match.params.billingID,
      cospaceplanservice: {},
    };
  }

  componentDidMount() {
    CoSpacePlanServiceService.getCoSpacePlanServiceById(
      this.state.billingID
    ).then((res) => {
      console.log(res.data.data[0]);
      this.setState({ cospaceplanservice: res.data.data[0] });
    });
  }

  cancel() {
    this.props.history.push("/cospaceplanservices");
  }

  render() {
    return (
      <div>
        <br></br>
        <div className="card col-md-6 offset-md-3 bg-dark">
          <h3 className="text-center"> View CoSpacePlanService Details</h3>
          <div className="card-body">
            <div className="row">
              <label className="viewLabel"> CoWork Space Name : </label>
              <div> {this.state.cospaceplanservice.coworkName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> Service Type : </label>
              <div> {this.state.cospaceplanservice.serviceTypeName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> Plan Type : </label>
              <div> {this.state.cospaceplanservice.planName}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> Rate: </label>
              <div> {this.state.cospaceplanservice.rate}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> Discount: </label>
              <div> {this.state.cospaceplanservice.discount}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> GST: </label>
              <div> {this.state.cospaceplanservice.gst}</div>
            </div>

            <div className="row">
              <label className="viewLabel"> Actual Qty: </label>
              <div> {this.state.cospaceplanservice.actQty}</div>
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={this.cancel.bind(this)}
            style={{ marginLeft: "10px" }}
          >
            Back
          </button>
        </div>
      </div>
    );
  }
}

export default ClientViewCoSpacePlanServiceComponent;
