import React, { Component } from 'react'

class FooterComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <footer className = "footer">
                    <span className="text-muted"><h6>IACSD AKURDI PGDAC SEP 2021 BY- RIMA KHEDEKAR & AVINASH GAIKWAD</h6></span>
                </footer>
            </div>
        )
    }
}

export default FooterComponent
