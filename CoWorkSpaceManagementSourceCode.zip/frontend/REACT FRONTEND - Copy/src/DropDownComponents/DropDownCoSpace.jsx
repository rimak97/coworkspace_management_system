import React, { Component } from "react";
import axios from "axios";

class DropDownCoSpace extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectOptions: [],
      selectedTeam: "",
      id: "",
      name: "",
    };

    console.log("In Constructor of Drop down");
  }

  async getOptions() {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    const res = await axios.get(
      "http://localhost:8080/coSpace/getAllCoSpace",
      jwtToken
    );
    const data = res.data.data;
    console.log("get");
    console.log(data);

    const options = data.map((d) => ({
      value: d.coworkID,
      label: d.coworkName,
    }));
    console.log("getOptions of Drop Down");
    console.log(options);

    this.setState({ selectOptions: options });
    console.log(this.state.selectOptions);
  }

  handleChange(e) {
    //this.setState({id:e.target.value, name:e.target.label})
    this.setState({ selectedTeam: e.target.value });
  }

  componentDidMount() {
    console.log("ComponentDID mount of Drop Down");
    this.getOptions();
  }

  render() {
    console.log(this.state.selectOptions);
    return (
      // Correct Code
      //   <div>
      //   <select value={this.state.selectedTeam} onChange={(e) => this.setState({selectedTeam: e.target.value})}>
      //     {this.state.selectOptions.map((team) => <option key={team.value} value={team.value}>{team.label}</option>)}
      //   </select>
      // </div>

      <div>
        <select
          value={this.state.selectedTeam}
          onChange={(e) => {
            this.setState({ selectedTeam: e.target.value });
            this.props.parentCallback(e.target.value);
          }}
        >
          <option value="none" selected>
            Select Cospace
          </option>
          {this.state.selectOptions.map((team) => (
            <option key={team.value} value={team.value}>
              {team.label}
            </option>
          ))}
        </select>
        {/* <h1>Selected ID={this.state.selectedTeam}</h1> 
      <h1>Selected Name={this.state.name}</h1>  */}
      </div>
    );
  }
}

export default DropDownCoSpace;
