import React, { Component } from "react";
import axios from "axios";
import TextField from "@material-ui/core/TextField";
import BookingService from "../services/BookingService";
//import ReactHTMLTableToExcel from "react-html-table-to-excel";
//import "../App.css";
import Swal from "sweetalert2";

export class CascadingDropdown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bookingID: "",
      userID: "",
      coworkID: "",
      startDate: "",
      bookedQty: "",
      amount: "",
      finalAmount: "",
      serviceTypeID: "",
      planTypeID: "",
      billingID: "",

      CoworkData: [],
      ServiceTypeData: [],

      PlanData: [],
      AmountData: [],
      rate: "",
      actQty: "",
      gst: "",
      discount: "",
      finalAmount: "",
      bookedQty: "",
      billingID: "",
    };

    this.changeBookedQtyHandler = this.changeBookedQtyHandler.bind(this);
    
    this.ChangeCoWorkSpace = this.ChangeCoWorkSpace.bind(this);
    this.ChangePlanType = this.ChangePlanType.bind(this);
    this.ChangeServiceType = this.ChangeServiceType.bind(this);
    this.addToCart = this.addToCart.bind(this);
    
    
  }

  componentDidMount() {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    axios
      .get("http://localhost:8080/coSpacePlanService/getCoworkSpaces", jwtToken)
      .then((response) => {
        console.log("response data");
        console.log(response);
        this.setState({
          CoworkData: response.data.data,
        });
        console.log("CoWork Data");
        console.log(this.state.CoworkData);
      });

    // console.log("CoWork Data")
    // console.log(this.state.CoworkData)
  }

  ChangeCoWorkSpace = (e) => {
    this.setState({
      coworkID: e.target.value,
    });

    console.log("cowork id");
    console.log(e.target.value);

    const jwtToken = {
      headers: { token: sessionStorage.token },
    };

    axios
      .get(
        "http://localhost:8080/coSpacePlanService/getServiceTypesByCoworkID/" +
          e.target.value,
        jwtToken
      )
      .then((response) => {
        console.log(response);
        this.setState({
          ServiceTypeData: response.data.data,
        });
        console.log("ServiceType Data");
        console.log(this.state.ServiceTypeData);
      });
  };

  ChangeServiceType = (e) => {
    this.setState({
      serviceTypeID: e.target.value,
    });

    const jwtToken = {
      headers: { token: sessionStorage.token },
    };

    axios
      .get(
        "http://localhost:8080/coSpacePlanService/getPlanTypesByCoworkIDServiceID/" +
          this.state.coworkID +
          "/" +
          e.target.value,
        jwtToken
      )
      .then((response) => {
        console.log("plan response");
        console.log(response);
        this.setState({
          PlanData: response.data.data,
        });
      });

    // console.log("Plan Data")
    // console.log(this.state.PlanData)
  };

  ChangePlanType = (e) => {
    this.setState({
      planTypeID: e.target.value,
    });

    const jwtToken = {
      headers: { token: sessionStorage.token },
    };

    axios
      .get(
        "http://localhost:8080/coSpacePlanService/getAmountDetailsByCoIDSeIDPlID/" +
          this.state.coworkID +
          "/" +
          this.state.serviceTypeID +
          "/" +
          e.target.value,
        jwtToken
      )
      .then((response) => {
        console.log("amount responsesdsssssssssss");
        console.log(response.data);
        this.setState({
          AmountData: response.data.data,
        });

        console.log("billing id details");
        console.log(this.state.AmountData);
      });
  };

  changeBookedQtyHandler = (event) => {
    console.log("Actual Qty" + this.state.AmountData[0].actQty);

    if (this.state.AmountData[0].actQty >= event.target.value) {
      console.log("rate" + this.state.AmountData[0].rate);
      this.setState({ bookedQty: event.target.value });

      this.setState({ rate: this.state.AmountData[0].rate });
      this.setState({ gst: this.state.AmountData[0].gst });
      this.setState({ actQty: this.state.AmountData[0].actQty });
      this.setState({ discount: this.state.AmountData[0].discount });
      //this.setState({billingID:this.setState.AmountData[0].billingID});

      const r = parseFloat(this.state.AmountData[0].rate);
      const b = parseFloat(event.target.value);
      const g = parseFloat(this.state.AmountData[0].gst);
      const d = parseFloat(this.state.AmountData[0].discount);

      console.log("r" + r + "b" + b + "g" + g + "d" + d);

      const famount = r * b + (r * b * g) / 100 - (r * b * d) / 100;

      this.setState({ finalAmount: famount });
    } else {
      let availQty = this.state.AmountData[0].actQty + 1;
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Try With Booking Qty Less than " + availQty,
        //footer: '<a href="">Why do I have this issue?</a>'
      });
    }
  };

  addToCart = (e) => {
    e.preventDefault();
    console.log("Billing ID");
    console.log(this.state.AmountData[0].billingID);
    let booking = {
      userID: sessionStorage.userID,
      coworkID: this.state.coworkID,
      startDate: this.state.startDate,

      bookedQty: this.state.bookedQty,
      amount: this.state.rate,
      finalAmount: this.state.finalAmount,
      serviceTypeID: this.state.serviceTypeID,
      planTypeID: this.state.planTypeID,
      billingID: this.state.AmountData[0].billingID,
    };
    console.log("booking => " + JSON.stringify(booking));
    BookingService.createBooking(booking).then((res) => {
      if(res.status=="error")
      {
        alert("Data is Not Added Sucessfully")
      }
      else{
        this.props.history.push("/bookings");

      }
      
      
    });
    
  };

  cancel() {
    this.props.history.push("/bookings");
  }

  render() {
    console.log("coworkID");
    console.log(this.state.coworkID);

    console.log("serviceID");
    console.log(this.state.serviceTypeID);

    console.log("PlanID");
    console.log(this.state.planTypeID);

    console.log("SSSSSSSSSSS");
    console.log(this.state.rate);

    return (
      <div className="container">
        <div className="card col-md-8 offset-md-3 offset-md-3">
          <div class="row" className="hdr">
            <div class="col-sm-12 btn btn-info">My Booking</div>
            <div className="form-group dropdn">
              <select
                className="form-control"
                name="country"
                value={this.state.coworkID}
                onChange={this.ChangeCoWorkSpace}
              >
                <option>Select CoWork Space</option>
                {this.state.CoworkData.map((e, key) => {
                  return (
                    <option key={key} value={e.coworkID}>
                      {e.coworkName}
                    </option>
                  );
                })}
              </select>

              <select
                className="form-control slct"
                name="state"
                value={this.state.serviceTypeID}
                onChange={this.ChangeServiceType}
              >
                <label for="company">State Name</label>
                <option>Select Service</option>
                {this.state.ServiceTypeData.map((e, key) => {
                  return (
                    <option key={key} value={e.serviceTypeID}>
                      {e.serviceTypeName}
                    </option>
                  );
                })}
              </select>

              <select
                className="form-control"
                name="country"
                value={this.state.planTypeID}
                onChange={this.ChangePlanType}
              >
                <option>Select Plan Type</option>
                {this.state.PlanData.map((e, key) => {
                  return (
                    <option key={key} value={e.planTypeID}>
                      {e.planName}
                    </option>
                  );
                })}
              </select>
              <br></br>

              <div className="form-group">
                <label> Start Date: </label>
                <br></br>
                <TextField
                  id="date"
                  type="date"
                  onChange={(e) => {
                    this.setState({ startDate: e.target.value });
                  }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>

              <div className="form-group">
                <label> Booked Qty: </label>
                <input
                  placeholder="Booked Qty"
                  name="bookedQty"
                  className="form-control"
                  value={this.state.bookedQty}
                  onChange={this.changeBookedQtyHandler}
                />
              </div>

              <div className="form-group">
                <label> Rate: </label>
                <input
                  name="rate"
                  className="form-control"
                  value={this.state.rate}
                  readOnly
                />
              </div>

              <div className="form-group">
                <label> GST: </label>
                <input
                  name="gst"
                  className="form-control"
                  value={this.state.gst}
                  readOnly
                />
              </div>

              <div className="form-group">
                <label> Discount: </label>
                <input
                  name="rate"
                  className="form-control"
                  value={this.state.discount}
                  readOnly
                />
              </div>

              <div className="form-group">
                <label> Final Amount: </label>
                <input
                  name="rate"
                  className="form-control"
                  value={this.state.finalAmount}
                  readOnly
                />
              </div>

              <button className="btn btn-success" onClick={this.addToCart}>
                Add to Cart
              </button>


              <button
                    className="btn btn-danger float-right"
                    onClick={this.cancel.bind(this)}
                    style={{ marginLeft: "10px" }}
                  >
                    Cancel
                  </button>

              {/* <button
                className="btn btn-danger float-right"
                onClick={this.cancel.bind(this)}
                style={{ marginLeft: "10px" }}
              >
                Cancel
              </button> */}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CascadingDropdown;
