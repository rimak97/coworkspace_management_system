import axios from "axios";

const COSPACEPLANSERVICE_API_BASE_URL =
  "http://localhost:8080/coSpacePlanService";

class CoSpacePlanServiceService {
  getCoSpacePlanServices() {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      COSPACEPLANSERVICE_API_BASE_URL + "/getAllcospaceplanservice",
      jwtToken
    );
  }

  createCoSpacePlanService(cospaceplanservice) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(
      COSPACEPLANSERVICE_API_BASE_URL + "/addCoSpacePlanService",
      cospaceplanservice,
      jwtToken
    );
  }

  getCoSpacePlanServiceById(billingID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      COSPACEPLANSERVICE_API_BASE_URL +
        "/getCoSpacePlanServiceById/" +
        billingID,
      jwtToken
    );
  }

  updateCoSpacePlanService(cospaceplanservice, billingID) {
    console.log("Service" + billingID);
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      COSPACEPLANSERVICE_API_BASE_URL +
        "/updateCoSpacePlanServiceByBillingID/" +
        billingID,
      cospaceplanservice,
      jwtToken
    );
  }

  deleteCoSpacePlanService(billingID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      COSPACEPLANSERVICE_API_BASE_URL +
        "/deleteCoSpacePlanServiceByBillingID/" +
        billingID,
      jwtToken
    );
  }

  getServiceTypesByCoworkID(coworkID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      COSPACEPLANSERVICE_API_BASE_URL + "/getSerIDPlanIDByCoworkID/" + coworkID,
      jwtToken
    );
  }
}

export default new CoSpacePlanServiceService();
