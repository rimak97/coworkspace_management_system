import axios from "axios";

const Plan_API_BASE_URL = "http://localhost:8080/planType";

class PlanService {
  getPlans() {
    console.log("getplans");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(Plan_API_BASE_URL + "/getAllPlanTypes", jwtToken);
  }

  createPlan(plan) {
    console.log("createplan");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(Plan_API_BASE_URL + "/addPlanType", plan, jwtToken);
  }

  getPlanById(planTypeID) {
    console.log("get plan by id");
    console.log(planTypeID);
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      Plan_API_BASE_URL + "/getPlanTypeById/" + planTypeID,
      jwtToken
    );
  }

  updatePlan(plan, planTypeID) {
    console.log("updateplan");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      Plan_API_BASE_URL + "/updatePlanType/" + planTypeID,
      plan,
      jwtToken
    );
  }

  deletePlan(planTypeID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      Plan_API_BASE_URL + "/deletePlanTypeById/" + planTypeID,
      jwtToken
    );
  }
}

export default new PlanService();
