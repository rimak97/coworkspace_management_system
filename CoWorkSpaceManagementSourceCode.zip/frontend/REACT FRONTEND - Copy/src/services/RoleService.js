import axios from "axios";

const Role_API_BASE_URL = "http://localhost:8080/roleType";

class RoleService {
  getRoles() {
    console.log("getroles");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(Role_API_BASE_URL + "/getAllRoleNames", jwtToken);
  }

  createRole(role) {
    console.log("createrole");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(Role_API_BASE_URL + "/addRoleName", role, jwtToken);
  }

  getRoleById(roleID) {
    console.log("get role by id");
    console.log(roleID);
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      Role_API_BASE_URL + "/getRoleNameById/" + roleID,
      jwtToken
    );
  }

  updateRole(role, roleID) {
    console.log("updaterole");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(Role_API_BASE_URL + "/update/" + roleID, role, jwtToken);
  }

  deleteRole(roleId) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      Role_API_BASE_URL + "/deleteRoleById/" + roleId,
      jwtToken
    );
  }
}

export default new RoleService();
