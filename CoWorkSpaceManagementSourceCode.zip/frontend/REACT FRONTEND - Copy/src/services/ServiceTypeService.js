import axios from "axios";

const SERVICE_API_BASE_URL = "http://localhost:8080/serviceType";

class ServiceTypeService {
  getServiceTypes() {
    console.log("getservicetypes");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(SERVICE_API_BASE_URL + "/getAllServiceTypes", jwtToken);
  }

  createServiceType(servicetype) {
    console.log("createservicetype");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(
      SERVICE_API_BASE_URL + "/addServiceType",
      servicetype,
      jwtToken
    );
  }

  getServiceTypeById(serviceTypeID) {
    console.log("get servicetype by id");
    console.log(serviceTypeID);
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      SERVICE_API_BASE_URL + "/getServiceTypeById/" + serviceTypeID,
      jwtToken
    );
  }

  updateServiceType(servicetype, serviceTypeID) {
    console.log("updateservicetype");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      SERVICE_API_BASE_URL + "/updateServiceType/" + serviceTypeID,
      servicetype,
      jwtToken
    );
  }

  deleteServiceType(serviceTypeID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      SERVICE_API_BASE_URL + "/deleteServiceTypeById/" + serviceTypeID,
      jwtToken
    );
  }
}

export default new ServiceTypeService();
