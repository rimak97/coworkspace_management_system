import axios from "axios";

const COWORKSPACE_API_BASE_URL = "http://localhost:8080/coSpace";

class CoWorkSpaceService {
  getCoWorkSpaces() {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(COWORKSPACE_API_BASE_URL + "/getAllCoSpace", jwtToken);
  }

  createCoWorkSpace(coworkspace) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(
      COWORKSPACE_API_BASE_URL + "/addCospace",
      coworkspace,
      jwtToken
    );
  }

  getCoWorkSpaceById(coworkID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      COWORKSPACE_API_BASE_URL + "/getCospaceById/" + coworkID,
      jwtToken
    );
  }

  updateCoWorkSpace(coworkspace, coworkID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      COWORKSPACE_API_BASE_URL + "/updateCoSpace/" + coworkID,
      coworkspace,
      jwtToken
    );
  }

  deleteCoWorkSpace(coworkID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      COWORKSPACE_API_BASE_URL + "/deleteCospaceById/" + coworkID,jwtToken
    );
  }
}

export default new CoWorkSpaceService();
