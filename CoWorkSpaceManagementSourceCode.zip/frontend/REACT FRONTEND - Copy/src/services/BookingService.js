import axios from "axios";

const BOOKING_API_BASE_URL = "http://localhost:8080/bookings";

class BookingService {
  getBookings() {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(BOOKING_API_BASE_URL + "/getAllBookings", jwtToken);
  }

  createBooking(booking) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(
      BOOKING_API_BASE_URL + "/addNewBooking",
      booking,
      jwtToken
    );
  }

  getBookingById(bookingID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      BOOKING_API_BASE_URL + "/getBookingById/" + bookingID,
      jwtToken
    );
  }

  updateBooking(booking, bookingID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      BOOKING_API_BASE_URL + "/updateBooking/" + bookingID,
      booking,
      jwtToken
    );
  }

  deleteBooking(bookingID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      BOOKING_API_BASE_URL + "/deleteBookingById/" + bookingID,
      jwtToken
    );
  }
}

export default new BookingService();
