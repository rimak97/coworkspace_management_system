import axios from "axios";

const PaymentType_API_BASE_URL = "http://localhost:8080/paymenttype";

class PaymentTypeService {
  getPaymentTypes() {
    console.log("getpaymentTypes");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      PaymentType_API_BASE_URL + "/getAllPaymentTypeNames",
      jwtToken
    );
  }

  createPaymentType(paymentType) {
    console.log("createpaymentType");
    console.log(paymentType);
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(
      PaymentType_API_BASE_URL + "/addPaymentTypeName",
      paymentType,
      jwtToken
    );
  }

  getPaymentTypeById(paymentTypeID) {
    console.log("get Payment Type by id");
    console.log(paymentTypeID);
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      PaymentType_API_BASE_URL + "/getPaymentTypeNameById/" + paymentTypeID,
      jwtToken
    );
  }

  updatePaymentType(paymentType, paymentTypeID) {
    console.log("update paymentType");
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      PaymentType_API_BASE_URL + "/updatePaymentType/" + paymentTypeID,
      paymentType,
      jwtToken
    );
  }

  deletePaymentType(paymentTypeID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      PaymentType_API_BASE_URL + "/deletePaymentTypeNameById/" + paymentTypeID,
      jwtToken
    );
  }
}

export default new PaymentTypeService();
