import axios from "axios";

const USER_API_BASE_URL = "http://localhost:8080/users";

class UserService {
  getUsers() {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(USER_API_BASE_URL + "/getAllUserDetails", jwtToken);
  }

  createUser(user) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.post(USER_API_BASE_URL + "/addUser", user, jwtToken);
  }

  getUserById(userID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.get(
      USER_API_BASE_URL + "/getUserDetailsById/" + userID,
      jwtToken
    );
  }

  updateUser(user, userID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.put(
      USER_API_BASE_URL + "/updateUser/" + userID,
      user,
      jwtToken
    );
  }

  deleteUser(userID) {
    const jwtToken = {
      headers: { token: sessionStorage.token },
    };
    return axios.delete(
      USER_API_BASE_URL + "/deleteUserById/" + userID,
      jwtToken
    );
  }

  getUserByEmail(user) {
    return axios.post(USER_API_BASE_URL + "/getUserByEmail", user);
  }
}

export default new UserService();
