import React from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

//Routes for Super Admin Role Page
import SuperAdminListRole from "./components/Roles/SuperAdmin/ListRoleComponent";
import SuperAdminCreateRole from "./components/Roles/SuperAdmin/CreateRoleComponent";
import SuperAdminViewRole from "./components/Roles/SuperAdmin/ViewRoleComponent";

//Routes for Admin and Executive Role Page
import AdminExecutiveListRole from "./components/Roles/AdminExecutive/ListRoleComponent";
import AdminExecutiveViewRole from "./components/Roles/AdminExecutive/ViewRoleComponent";

//Routes for Super Admin Plan Page
import SuperAdminListPlan from "./components/Plans/Super Admin/ListPlanComponent";
import SuperAdminCreatePlan from "./components/Plans/Super Admin/CreatePlanComponent";
import SuperAdminViewPlan from "./components/Plans/Super Admin/ViewPlanComponent";


//Routes for Admin Executive Plan Page
import AdminExecutiveListPlan from "./components/Plans/Admin Executive/ListPlanComponent";
import AdminExecutiveViewPlan from "./components/Plans/Admin Executive/ViewPlanComponent";

//Routes for Super Admin Service Page
import SuperAdminListServiceType from "./components/Services/Super Admin/ListServiceTypeComponent";
import SuperAdminCreateServiceType from "./components/Services/Super Admin/CreateServiceTypeComponent";
import SuperAdminViewServiceType from "./components/Services/Super Admin/ViewServiceTypeComponent";

//Routes for Admin Executive Service Page
import AdminExecutiveListServiceType from "./components/Services/Admin Executive/ListServiceTypeComponent";
import AdminExecutiveViewServiceType from "./components/Services/Admin Executive/ViewServiceTypeComponent";

//Routes for Super Admin CoWork Space Page
import SuperAdminListCoWorkSpace from "./components/CoWorkSpace/Super Admin/ListCoWorkSpaceComponent";
import SuperAdminCreateCoWorkSpace from "./components/CoWorkSpace/Super Admin/CreateCoWorkSpaceComponent";
import SuperAdminViewCoWorkSpace from "./components/CoWorkSpace/Super Admin/ViewCoWorkSpaceComponent";


//Routes for Admin Executive CoWork Space Page
import AdminExecutiveListCoWorkSpace from "./components/CoWorkSpace/Admin/ListCoWorkSpaceComponent";
import AdminExecutiveCreateCoWorkSpace from "./components/CoWorkSpace/Admin/CreateCoWorkSpaceComponent";
import AdminExecutiveViewCoWorkSpace from "./components/CoWorkSpace/Admin/ViewCoWorkSpaceComponent";


//Routes for Executive CoWork Space Page
import ExecutiveListCoWorkSpace from "./components/CoWorkSpace/Executive/ListCoWorkSpaceComponent";
import ExecutiveViewCoWorkSpace from "./components/CoWorkSpace/Executive/ViewCoWorkSpaceComponent";

//Routes for Client CoWork Space Page
import ClientListCoWorkSpace from "./components/CoWorkSpace/Client/ListCoWorkSpaceComponent";
import ClientViewCoWorkSpace from "./components/CoWorkSpace/Client/ViewCoWorkSpaceComponent";

//Routes for Super Admin Payment Types pages
import SuperAdminListPaymentType from "./components/PaymentType/Super Admin/ListPaymentTypeComponent";
import SuperAdminCreatePaymentType from "./components/PaymentType/Super Admin/CreatePaymentTypeComponent";
import SuperAdminViewPaymentType from "./components/PaymentType/Super Admin/ViewPaymentTypeComponent";


//Routes for Admin and Executive Payment Types pages
import AdminExecutiveListPaymentType from "./components/PaymentType/Admin Executive/ListPaymentTypeComponent";
import AdminExecutiveViewPaymentType from "./components/PaymentType/Admin Executive/ViewPaymentTypeComponent";


//Routes for Super Admin User Types pages
import SuperAdminListUser from "./components/Users/Super Admin/ListUserComponent";
import SuperAdminCreateUser from "./components/Users/Super Admin/CreateUserComponent";
import SuperAdminViewUser from "./components/Users/Super Admin/ViewUserComponent";


//Routes for Admin Executive Payment Types pages
import AdminExecutiveListUser from "./components/Users/Admin Executive/ListUserComponent";
import AdminExecutiveViewUser from "./components/Users/Admin Executive/ViewUserComponent";
import AdminExecutiveCreateUser from "./components/Users/Admin Executive/CreateUserComponent";

//Routes for Client Payment Types pages
import ClientListUser from "./components/Users/Client/ListUserComponent";
import ClientViewUser from "./components/Users/Client/ViewUserComponent";
import ClientCreateUser from "./components/Users/Client/CreateUserComponent";










import ListRoleComponent from "./components/Roles/ListRoleComponent";
import CreateRoleComponent from "./components/Roles/CreateRoleComponent";
import ViewRoleComponent from "./components/Roles/ViewRoleComponent";

import ListPlanComponent from "./components/Plans/ListPlanComponent";
import CreatePlanComponent from "./components/Plans/CreatePlanComponent";
import ViewPlanComponent from "./components/Plans/ViewPlanComponent";

import ListServiceTypeComponent from "./components/Services/ListServiceTypeComponent";
import CreateServiceTypeComponent from "./components/Services/CreateServiceTypeComponent";
import ViewServiceTypeComponent from "./components/Services/ViewServiceTypeComponent";

import ListPaymentTypeComponent from "./components/PaymentType/ListPaymentTypeComponent";
import CreatePaymentTypeComponent from "./components/PaymentType/CreatePaymentTypeComponent";
import ViewPaymentTypeComponent from "./components/PaymentType/ViewPaymentTypeComponent";

import ListUserComponent from "./components/Users/ListUserComponent";
import CreateUserComponent from "./components/Users/CreateUserComponent";
import ViewUserComponent from "./components/Users/ViewUserComponent";

import ListCoWorkSpaceComponent from "./components/CoWorkSpace/ListCoWorkSpaceComponent";
import CreateCoWorkSpaceComponent from "./components/CoWorkSpace/CreateCoWorkSpaceComponent";
import ViewCoWorkSpaceComponent from "./components/CoWorkSpace/ViewCoWorkSpaceComponent";

import ListCoSpacePlanServiceComponent from "./components/CoSpacePlanService/ListCoSpacePlanServiceComponent";
import CreateCoSpacePlanServiceComponent from "./components/CoSpacePlanService/CreateCoSpacePlanServiceComponent";
import ViewCoSpacePlanServiceComponent from "./components/CoSpacePlanService/ViewCoSpacePlanServiceComponent";

import ListBookingComponent from "./components/Bookings/ListBookingComponent";
import CreateBookingComponent from "./components/Bookings/CreateBookingComponent";
import ViewBookingComponent from "./components/Bookings/ViewBookingComponent";

import Home from "./components/Home";
import DropDown from "./components/CoSpacePlanService/DropDown";

import login from "./components/Login/login";
import HomeNavBar from "./components/Home/HomeNavBar";
import bookForMe from "./components/Bookings/bookForMe";
import signup from "./components/Login/signup";
import ClientListCoSpacePlanServiceComponent from "./components/CoSpacePlanService/Client/ClientListCoSpacePlanServiceComponent";

import ExecuiveListUserComponent from "./components/Users/Executive/ExecutiveListUserComponent";
import ExecuiveViewUserComponent from "./components/Users/Executive/ExecutiveViewUserComponent";


function App() {
  return (
    <div class="bg-image">
      <HomeNavBar />
      <Router>
        {/* <HeaderComponent /> */}

        <div className="container">
          <Switch>

          {/* Routes for Super Admin Role Page */}
          <Route path="/superAdminRoles" component={SuperAdminListRole}></Route>
          <Route path="/add-SuperAdminrole/:roleID" component={SuperAdminCreateRole}></Route>
          <Route path="/view-SuperAdminrole/:roleID" component={SuperAdminViewRole}></Route>
          
          {/* Routes for Admin and Executive Role Page */}
          <Route path="/adminExecutiveRoles" component={AdminExecutiveListRole}></Route>
          <Route path="/view-AdminExecutiverole/:roleID" component={AdminExecutiveViewRole}></Route>
          

          {/* Routes for Super Admin Plan Page */}
          <Route path="/superAdminplans" component={SuperAdminListPlan}></Route>
          <Route path="/add-superAdminplan/:planTypeID"component={SuperAdminCreatePlan}></Route>
          <Route path="/view-superAdminplan/:planTypeID" component={SuperAdminViewPlan}></Route>

          {/* Routes for Admin and Executive Plan Page */}
          <Route path="/adminExecutiveplans" component={AdminExecutiveListPlan}></Route>
          <Route path="/view-adminExecutiveplan/:planTypeID" component={AdminExecutiveViewPlan}></Route>


          {/* Routes for Super Admin Service Page */}
          <Route path="/superAdminserviceTypes" component={SuperAdminListServiceType}></Route>
            <Route path="/add-superAdminserviceType/:serviceTypeID" component={SuperAdminCreateServiceType}></Route>
            <Route path="/view-superAdminserviceType/:serviceTypeID" component={SuperAdminViewServiceType}></Route>

            {/* Routes for Admin and Executive Service Page */}
            <Route path="/adminExecutiveserviceTypes" component={AdminExecutiveListServiceType}></Route>
            <Route path="/view-adminExecutiveserviceType/:serviceTypeID" component={AdminExecutiveViewServiceType}></Route>

            {/* Routes for Super Admin Cowork Space Page */}
            <Route path="/superAdmincoworkspaces" component={SuperAdminListCoWorkSpace}></Route>
            <Route path="/add-superAdmincoworkspace/:coworkID" component={SuperAdminCreateCoWorkSpace}></Route>
            <Route path="/view-superAdmincoworkspace/:coworkID" component={SuperAdminViewCoWorkSpace}></Route>


            {/* Routes for Admin  Cowork Space Page */}
            <Route path="/adminExecutivecoworkspaces" component={AdminExecutiveListCoWorkSpace}></Route>
            <Route path="/add-adminExecutivecoworkspace/:coworkID" component={AdminExecutiveCreateCoWorkSpace}></Route>
            <Route path="/view-adminExecutivecoworkspace/:coworkID" component={AdminExecutiveViewCoWorkSpace}></Route>

            {/* Routes for Executive Cowork Space Page */}  
            <Route path="/executivecoworkspaces" component={ExecutiveListCoWorkSpace}></Route>
            <Route path="/view-executivecoworkspace/:coworkID" component={ExecutiveViewCoWorkSpace}></Route>


            {/* Routes for Client Cowork Space Page */}  
            <Route path="/clientcoworkspaces" component={ClientListCoWorkSpace}></Route>
            <Route path="/view-clientcoworkspace/:coworkID" component={ClientViewCoWorkSpace}></Route>

            {/* Routes for Super Admin Payment Type Page */}
            <Route path="/superAdminpaymentTypes" component={SuperAdminListPaymentType}></Route>
            <Route path="/add-superAdminpaymentType/:paymentTypeID" component={SuperAdminCreatePaymentType}></Route>
            <Route path="/view-superAdminpaymentType/:paymentTypeID" component={SuperAdminViewPaymentType}></Route>

            {/* Routes for Admin Executive Payment Type Page */}
            <Route path="/adminExecutivepaymentTypes" component={AdminExecutiveListPaymentType}></Route>
            <Route path="/view-adminExecutivepaymentType/:paymentTypeID" component={AdminExecutiveViewPaymentType}></Route>

            {/* Routes for Super Admin User Page */}
            <Route path="/superAdminusers" component={SuperAdminListUser}></Route>
            <Route path="/add-superAdminuser/:userID" component={SuperAdminCreateUser}></Route>
            <Route path="/view-superAdminuser/:userID" component={SuperAdminViewUser}></Route>


            {/* Routes for Super Admin User Page */}
            <Route path="/adminExecutiveusers" component={AdminExecutiveListUser}></Route>
            <Route path="/add-adminExecutiveuser/:userID" component={AdminExecutiveCreateUser}></Route>
            <Route path="/view-adminExecutiveuser/:userID" component={AdminExecutiveViewUser}></Route>

            {/* Routes for client User Page */}
            <Route path="/clientusers" component={ClientListUser}></Route>
            <Route path="/add-clientuser/:userID" component={ClientCreateUser}></Route>
            <Route path="/view-clientuser/:userID" component={ClientViewUser}></Route>

















            <Route
              path="/view-execuser/:userID"
              component={ExecuiveViewUserComponent}
            ></Route>
            <Route
              path="/ExecuiveListUserComponent"
              component={ExecuiveListUserComponent}
            ></Route>
            <Route
              path="/ClientListCoSpacePlanService"
              component={ClientListCoSpacePlanServiceComponent}
            ></Route>
            <Route path="/login" component={login}></Route>
            <Route path="/signup" component={signup}></Route>
            <Route path="/homeDashBoard" component={HomeNavBar}></Route>
            <Route path="/bookForMe" component={bookForMe}></Route>

            <Route path="/home" exact component={Home}></Route>
            <Route path="/" exact component={login}></Route>

            

            <Route path="/plans" component={ListPlanComponent}></Route>
            <Route path="/add-plan/:planTypeID"component={CreatePlanComponent}></Route>
            <Route path="/view-plan/:planTypeID" component={ViewPlanComponent}></Route>

            <Route path="/serviceTypes" component={ListServiceTypeComponent}></Route>
            <Route path="/add-serviceType/:serviceTypeID" component={CreateServiceTypeComponent}></Route>
            <Route path="/view-serviceType/:serviceTypeID" component={ViewServiceTypeComponent}></Route>

            <Route path="/paymentTypes" component={ListPaymentTypeComponent}></Route>
            <Route path="/add-paymentType/:paymentTypeID" component={CreatePaymentTypeComponent}></Route>
            <Route path="/view-paymentType/:paymentTypeID" component={ViewPaymentTypeComponent}></Route>







            <Route path="/paymentTypes" component={ListPaymentTypeComponent}></Route>
            <Route path="/add-paymentType/:paymentTypeID" component={CreatePaymentTypeComponent}></Route>
            <Route path="/view-paymentType/:paymentTypeID" component={ViewPaymentTypeComponent}></Route>

            <Route path="/users" component={ListUserComponent}></Route>
            <Route path="/add-user/:userID" component={CreateUserComponent}></Route>
            <Route path="/view-user/:userID" component={ViewUserComponent}></Route>

            <Route path="/coworkspaces" component={ListCoWorkSpaceComponent}></Route>
            <Route path="/add-coworkspace/:coworkID" component={CreateCoWorkSpaceComponent}></Route>
            <Route path="/view-coworkspace/:coworkID" component={ViewCoWorkSpaceComponent}></Route>

            <Route
              path="/cospaceplanservices"
              component={ListCoSpacePlanServiceComponent}
            ></Route>
            <Route
              path="/add-cospaceplanservice/:billingID"
              component={CreateCoSpacePlanServiceComponent}
            ></Route>
            <Route
              path="/view-cospaceplanservice/:billingID"
              component={ViewCoSpacePlanServiceComponent}
            ></Route>

            <Route path="/bookings" component={ListBookingComponent}></Route>
            <Route
              path="/add-booking/:bookingID"
              component={CreateBookingComponent}
            ></Route>
            <Route
              path="/view-booking/:bookingID"
              component={ViewBookingComponent}
            ></Route>

            <Route path="/DropDown" component={DropDown}></Route>

            {/* <Route path = "/update-employee/:id" component = {UpdateEmployeeComponent}></Route> */}
          </Switch>
        </div>
        {/* <FooterComponent /> */}
      </Router>
    </div>
  );
}

export default App;
