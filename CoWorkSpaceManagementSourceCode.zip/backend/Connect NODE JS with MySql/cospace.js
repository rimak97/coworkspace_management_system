// Name of Web Service --> coworkspace

//New Line Added By Avinash

// List of all Webservice modules
// 1 Get All CoworkSpaces Details
// 2 Get CoworkSpcase Details By coworkId
// 3 Delete CoworkSpace Details by coworkId
// 4 Update CoworkSpace Details by coworkId
// 5 Add New Cospace details
// 6 Get CoworkSpcase Details By Address (Search)

//const { response } = require("express");
//const { request } = require("http");

//Import all required
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All CoworkSpaces Details -->Example of URL--> /getAllCoSpace
router.get("/getAllCoSpace", (request, response) => {
  //const queryStatement = `select coworkID, coworkName,address,contactNumber,email,website from coworkspace`
  const queryStatement = `select * from coworkspace`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 2 Get CoworkSpcase Details By coworkID -->Example of URL--> /getCospaceById/:cospaceId=/getCospaceById/1
router.get("/getCospaceById/:cospaceId", (request, response) => {
  const cospaceId = request.params.cospaceId;
  const queryStatement = `select * from coworkspace where coworkID=${cospaceId}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 3 Delete CoworkSpace Details by coworkId -->Example of URL--> /deleteCospaceById/:cospaceId=/deleteCospaceById/2
router.delete("/deleteCospaceById/:cospaceId", (request, response) => {
  const cospaceId = request.params.cospaceId;
  const queryStatement = `delete from coworkspace where coworkID=${cospaceId}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 4 Update CoworkSpace Details By CoworkID -->Example of URL--> /updateCoSpace/:coworkId=/updateCoSpace/3
router.put("/updateCoSpace/:cospaceId", (request, response) => {
  const cospaceId = request.params.cospaceId;
  const { coworkName, address, contactNumber, email, website } = request.body;
  const queryStatement = `update coworkspace set coworkName = '${coworkName}', address = '${address}', contactNumber = '${contactNumber}', email = '${email}', website = '${website}' where coworkID = ${cospaceId}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 5 Add New Coworkspace. coworkID is Auto Increament -->Example of URL--> /addCospace
router.post("/addCospace", (request, response) => {
  const { coworkName, address, contactNumber, email, website } = request.body;
  const queryStatement = `insert into coworkspace(coworkID,coworkName, address, contactNumber, email, website) values (default,'${coworkName}', '${address}',  '${contactNumber}', '${email}', '${website}')`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 6 Get CoworkSpcase Details By Address (Search) -->Example of URL--> /getCospaceById/:cospaceId=/getCospaceById/1
router.get("/getCospaceByAddress/:address", (request, response) => {
  const address = request.params.address;
  const queryStatement = `select * from coworkspace where address='${address}'`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Export Router Module
module.exports = router;
