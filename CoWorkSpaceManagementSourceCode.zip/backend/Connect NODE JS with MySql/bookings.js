//Import all required
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All bookings
router.get("/getAllBookings", (request, response) => {
  const queryStatement = `select a.bookingID, b.firstName, c.coworkName, a.startDate, a.bookedQty,a.amount, a.finalAmount, d.serviceTypeName, e.planName, f.billingID from booking a inner join users b on a.userID=b.userID inner join coworkspace c on a.coworkID=c.coworkID inner join servicetypes d on a.serviceTypeID=d.serviceTypeID inner join plantypes e on a.planTypeID=e.planTypeID inner join cospaceplanservice f on a.coworkID=f.coworkID and a.serviceTypeID=f.serviceTypeID and a.planTypeID=f.planTypeID` ;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});


// 1 Get All bookings
router.get("/getAllBookingsOld", (request, response) => {
  const queryStatement = `select * from booking`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 2 Get booking by bookingID
router.get("/getBookingById/:bookingID", (request, response) => {
  const bookingID = request.params.bookingID;
  const queryStatement = `select * from booking where bookingID=${bookingID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 3 Delete booking by booking ID
router.delete("/deleteBookingById/:bookingID", (request, response) => {
  const bookingID = request.params.bookingID;
  const queryStatement = `delete from booking where bookingID=${bookingID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 4 Update booking by Booking ID
router.put("/updateBooking/:bookingID", (request, response) => {
    const bookingID = request.params.bookingID;
  
  const coworkID = request.body.coworkID;
  const userID = request.body.userID;
  const billingID = request.body.billingID;
  const startDate = request.body.startDate;
  
  const bookedQty = request.body.bookedQty;
  const amount = request.body.amount;
  const finalAmount = request.body.finalAmount;
  const serviceTypeID = request.body.serviceTypeID;
  const planTypeID = request.body.planTypeID;
   

  const queryStatement = `update booking set coworkID = '${coworkID}', userID = '${userID}', billingID = '${billingID}', startDate = '${startDate}', bookedQty = '${bookedQty}', amount = '${amount}', finalAmount = '${finalAmount}', serviceTypeID = '${serviceTypeID}',planTypeID= '${planTypeID}'where bookingID = ${bookingID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 5 Add New booking
router.post("/addNewBooking", (request, response) => {
    const coworkID = request.body.coworkID;
    const userID = request.body.userID;
    const billingID = request.body.billingID;
    const startDate = request.body.startDate;
    const bookedQty = request.body.bookedQty;
    const amount = request.body.amount;
    const finalAmount = request.body.finalAmount;
    const serviceTypeID = request.body.serviceTypeID;
    const planTypeID = request.body.planTypeID;

  const queryStatement = `insert into booking(bookingID, coworkID , userID , billingID , startDate , bookedQty , amount , finalAmount , serviceTypeID ,planTypeID ) values (default, '${coworkID}', '${userID}', '${billingID}', '${startDate}', '${bookedQty}', '${amount}', '${finalAmount}', '${serviceTypeID}', '${planTypeID}')`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Export Router Module
module.exports = router;
