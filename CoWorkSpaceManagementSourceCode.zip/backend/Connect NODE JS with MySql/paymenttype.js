// Name of Web Service --> paymenttype

// 1 Get All Payment Type Names
// 2 Get Payment Type Name by paymentTypeID
// 3 Delete Payment Type by paymentTypeID
// 4 Update Payment Type Name By paymentTypeID
// 5 Add New Payment Type Name

const { request, response } = require("express");
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All Payment Type Names -->Example of URL--> /getAllPaymentTypeNames
router.get("/getAllPaymentTypeNames", (request, response) => {
  const queryStatement = `select * from paymenttype`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 2 Get Payment Type Name by paymentTypeID -->Example of URL--> /getPaymentTypeNameById/:paymentTypeID=/getPaymentTypeNameById/100
router.get("/getPaymentTypeNameById/:paymentTypeID", (request, response) => {
    const paymentTypeID = request.params.paymentTypeID;
  const queryStatement = `select * from paymenttype where paymentTypeID=${paymentTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 3 Delete Payment Type by paymentTypeID -->Example of URL--> /deletePaymentTypeNameByID/200
router.delete("/deletePaymentTypeNameById/:paymentTypeID", (request, response) => {
    const paymentTypeID = request.params.paymentTypeID;
  const queryStatement = `delete from paymenttype where paymentTypeID=${paymentTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 4 Update Payment Type Name By paymentTypeID -->Example of URL--> /updatePaymentType/:paymentTypeID=/updatePaymentType/4
router.put("/updatePaymentType/:paymentTypeID", (request, response) => {
  const paymentTypeID = request.params.paymentTypeID;
  const paymentTypeName = request.body.paymentTypeName;
  const queryStatement = `update paymenttype set paymentTypeName = '${paymentTypeName}' where paymentTypeID = ${paymentTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 5 Add New Payment Type Name. paymentTypeID is Auto Increament -->Example of URL--> /addPaymentTypeName
router.post("/addPaymentTypeName", (request, response) => {
  const paymentTypeName = request.body.paymentTypeName;
  const queryStatement = `insert into paymenttype(paymentTypeID, paymentTypeName) values (default,'${paymentTypeName}')`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Export Router Module
module.exports = router;
