// Name of Web Service --> coSpacePlanService

// List of all Webservice modules
// 1 Get All CoSpace Plan Service Details
// 2 Get Rate By coworkID & serviceTypeID & planTypeID
// 3 Get Disount By coworkID & serviceTypeID & planTypeID
// 4 Get GST By coworkID & serviceTypeID & planTypeID
// 5 Get Actual Quantity By coworkID & serviceTypeID & planTypeID
// 6 Get Rate , Discount, GST, Actual Quantity By coworkID & serviceTypeID & planTypeID
// 7 Delete coSpaceServicePlan Details
// 8 Update coSpaceServicePlan Details
// 9 Add New coSpaceServicePlan Details
// 10 Get Billing ID By coworkID & serviceTypeID & planTypeID

//Import all required
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All CoSpace Plan Service Details -->Example of URL--> /getAllcospaceplanservice
router.get("/getAllcospaceplanserviceOld", (request, response) => {
  const queryStatement = `select * from cospaceplanservice`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 1 Get All CoSpace Plan Service Details -->Example of URL--> /getAllcospaceplanservice
router.get("/getAllcospaceplanservice", (request, response) => {
  const queryStatement = `select cps.billingID, cw.coworkName, pl.planName, st.serviceTypeName, cps.rate, cps.discount,cps.gst, cps.actQty from cospaceplanservice cps inner join coworkspace cw on cps.coworkID=cw.coworkID inner join plantypes pl on cps.planTypeID=pl.planTypeID inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});



// 2 Get Rate By coworkID & serviceTypeID & planTypeID   -->Example of URL--> /getRate/:coworkID/:serviceTypeID/:planTypeID
router.get("/getRate/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `select rate from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// 3 Get Disount By coworkID & serviceTypeID & planTypeID   -->Example of URL--> /getDiscount/:coworkID/:serviceTypeID/:planTypeID
router.get("/getDiscount/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `select discount from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// 4 Get GST By coworkID & serviceTypeID & planTypeID   -->Example of URL--> /getGST/:coworkID/:serviceTypeID/:planTypeID
router.get("/getGST/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `select gst from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// 5 Get Actual Quantity By coworkID & serviceTypeID & planTypeID   -->Example of URL--> /getActQty/:coworkID/:serviceTypeID/:planTypeID
router.get("/getActQty/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `select actQty from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// 6 Get Rate , Discount, GST, Actual Quantity By coworkID & serviceTypeID & planTypeID   -->Example of URL--> /getRateDiscountGstActQty/:coworkID/:serviceTypeID/:planTypeID
router.get("/getRateDiscountGstActQty/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `select rate, discount, gst, actQty from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// 7 Delete coSpaceServicePlan Details -->Example of URL--> /deleteCoSpacePlanService/:coworkID/:serviceTypeID/:planTypeID
router.delete("/deleteCoSpacePlanService/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `delete from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// 8 Update coSpaceServicePlan Details -->Example of URL--> /updateCoSpacePlanService/:coworkID/:serviceTypeID/:planTypeID
router.put("/updateCoSpacePlanService/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const { rate, discount, gst, actQty } = request.body;
    const queryStatement = `update cospaceplanservice set rate=${rate}, discount=${discount}, gst=${gst}, actQty=${actQty} where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});

// // 9 Add New coSpaceServicePlan Details. billingID is Auto Increament -->Example of URL--> /addCoSpacePlanService
// router.post("/addCoSpacePlanService", (request, response) => {
//   const { coworkID, serviceTypeID, planTypeID, rate, discount, gst, actQty } =
//     request.body;
//     console.log("body")
//     console.log(request.body)
//   const queryStatement = `insert into cospaceplanservice(billingID, coworkID, serviceTypeID, planTypeID, rate, discount, gst, actQty) values (default,${coworkID}, ${serviceTypeID}, ${planTypeID}, ${rate}, ${discount}, ${gst}, ${actQty})`;
//   db.query(queryStatement, (error, data) => {
//     response.send(utility.checkResult(error, data));
//   });
// });

// 9 Add New coSpaceServicePlan Details. billingID is Auto Increament -->Example of URL--> /addCoSpacePlanService
router.post("/addCoSpacePlanService", (request, response) => {
  const coworkID=request.body.coworkID;
  const serviceTypeID=request.body.serviceTypeID;
  const planTypeID=request.body.planTypeID;
  const rate=request.body.rate;
  const gst=request.body.gst;
  const discount=request.body.discount;
  const actQty=request.body.actQty;
  alert(rate);
  const queryStatement=`insert into cospaceplanservice(billingID,coworkID,serviceTypeID, planTypeID, rate, gst,discount,actQty) values (default,${coworkID}, ${serviceTypeID}, ${planTypeID}, ${rate}, ${discount}, ${gst}, ${actQty})`
   
  
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 10 Get Billing ID By coworkID & serviceTypeID & planTypeID   -->Example of URL--> /getBillingID/:coworkID/:serviceTypeID/:planTypeID
router.get("/getBillingID/:coworkID/:serviceTypeID/:planTypeID",(request, response) => {
    const { coworkID, serviceTypeID, planTypeID } = request.params;
    const queryStatement = `select billingID from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});


// get cospace plan service by id
router.get("/getCoSpacePlanServiceById/:billingID", (request, response) => {
  const billingID = request.params.billingID;
  const queryStatement = `select cps.billingID, cw.coworkName, pl.planName, st.serviceTypeName, cps.rate, cps.discount,cps.gst, cps.actQty from cospaceplanservice cps inner join coworkspace cw on cps.coworkID=cw.coworkID inner join plantypes pl on cps.planTypeID=pl.planTypeID inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.billingID=${billingID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});



// get cospace plan service by id
router.get("/getSerIDPlanIDByCoworkID/:coworkID", (request, response) => {
  const coworkID = request.params.coworkID;
  const queryStatement = `select cps.billingID, cw.coworkName, pl.planName, st.serviceTypeName, pl.planTypeID,st.serviceTypeID, cps.rate, cps.discount,cps.gst, cps.actQty from cospaceplanservice cps inner join coworkspace cw on cps.coworkID=cw.coworkID inner join plantypes pl on cps.planTypeID=pl.planTypeID inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  //const queryStatement = `select distinct st.serviceTypeName,cps.serviceTypeID from cospaceplanservice cps inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});


// 8 Update coSpaceServicePlan by Billing ID
router.put("/updateCoSpacePlanServiceByBillingID/:billingID",(request, response) => {
  const billingID = request.params.billingID;
  const { coworkID, serviceTypeID, planTypeID, rate, discount, gst, actQty } = request.body;
  const queryStatement = `update cospaceplanservice set coworkID='${coworkID}', serviceTypeID='${serviceTypeID}', planTypeID='${planTypeID}', rate='${rate}', discount='${discount}', gst='${gst}', actQty='${actQty}' where billingID = ${billingID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 7 Delete coSpaceServicePlan by Billing id
router.delete("/deleteCoSpacePlanServiceByBillingID/:billingID",(request, response) => {
  const { billingID } = request.params.billingID;
  const queryStatement = `delete from cospaceplanservice where billingID=${billingID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});


//Get CoworkSpace ID and CoWork Name
router.get("/getCoworkSpaces", (request, response) => {
  const queryStatement = `select distinct cps.coworkID, cw.coworkName from cospaceplanservice cps inner join coworkspace cw on cps.coworkID=cw.coworkID`;
  //const queryStatement = `select distinct st.serviceTypeName,cps.serviceTypeID from cospaceplanservice cps inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Get ServiceType ID and ServiceType Name by using coworkID
router.get("/getServiceTypesByCoworkID/:coworkID", (request, response) => {
  const coworkID = request.params.coworkID;
  const queryStatement = `select distinct cps.serviceTypeID, st.serviceTypeName from cospaceplanservice cps inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  //const queryStatement = `select distinct st.serviceTypeName,cps.serviceTypeID from cospaceplanservice cps inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});


//Get planType ID and PlanType Name by using coworkID and ServiceTypeID
router.get("/getPlanTypesByCoworkIDServiceID/:coworkID/:serviceTypeID", (request, response) => {
  const coworkID = request.params.coworkID;
  const serviceTypeID = request.params.serviceTypeID;
  const queryStatement = `select distinct cps.planTypeID, pt.planName from cospaceplanservice cps inner join plantypes pt on cps.planTypeID=pt.planTypeID where cps.coworkID=${coworkID} and cps.serviceTypeID=${serviceTypeID}`;
  //const queryStatement = `select distinct st.serviceTypeName,cps.serviceTypeID from cospaceplanservice cps inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});


//Get planType ID and PlanType Name by using coworkID and ServiceTypeID
router.get("/getAmountDetailsByCoIDSeIDPlID/:coworkID/:serviceTypeID/:planTypeID", (request, response) => {
  const coworkID = request.params.coworkID;
  const serviceTypeID = request.params.serviceTypeID;
  const planTypeID = request.params.planTypeID;
  const queryStatement = `select billingID, rate, gst, discount, actQty from cospaceplanservice where coworkID=${coworkID} and serviceTypeID=${serviceTypeID} and planTypeID=${planTypeID}`;
  //const queryStatement = `select distinct st.serviceTypeName,cps.serviceTypeID from cospaceplanservice cps inner join servicetypes st on cps.serviceTypeID=st.serviceTypeID where cps.coworkID=${coworkID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});




//Export Router Module
module.exports = router;
