// Name of Web Service --> planType

// List of all Webservice modules
// 1 Get All Plan Types Details
// 2 Get Plan Type Detail By planTypeID
// 3 Delete Plan Type Detail By planTypeID
// 4 Update Plan Type Details By planTypeID
// 5 Add New Plan Type. planTypeID is Auto Increament

//Import all required
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All Plan Types Details -->Example of URL--> /getAllPlanTypes
router.get("/getAllPlanTypes", (request, response) => {
  const queryStatement = `select * from plantypes`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 2 Get Plan Type Detail By planTypeID -->Example of URL--> /getPlanTypeById/:planTypeID=/getPlanTypeById/20
router.get("/getPlanTypeById/:planTypeID", (request, response) => {
  const planTypeID = request.params.planTypeID;
  const queryStatement = `select * from plantypes where planTypeID=${planTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 3 Delete Plan Type Detail By planTypeID -->Example of URL--> /deletePlanTypeById/:planTypeID=/deletePlanTypeById/100
router.delete("/deletePlanTypeById/:planTypeID", (request, response) => {
  const planTypeID = request.params.planTypeID;
  const queryStatement = `delete from plantypes where planTypeID=${planTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 4 Update Plan Type Details By planTypeID -->Example of URL--> /updatePlanType/:planTypeID=/updatePlanType/200
router.put("/updatePlanType/:planTypeID", (request, response) => {
  const planTypeID = request.params.planTypeID;
  const planName = request.body.planName;
  const queryStatement = `update plantypes set planName = '${planName}' where planTypeID = ${planTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 5 Add New Plan Type. planTypeID is Auto Increament -->Example of URL--> /addPlanType
router.post("/addPlanType", (request, response) => {
  const planName = request.body.planName;
  const queryStatement = `insert into plantypes(planTypeID, planName) values (default,'${planName}')`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Export Router Module
module.exports = router;
