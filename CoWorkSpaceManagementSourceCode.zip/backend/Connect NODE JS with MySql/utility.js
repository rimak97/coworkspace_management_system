//checkResult() method check whether error created or Not
function checkResult(error, data) {
    return error ? createError(error) : createSuccess(data)
}

//Sucess Method
function createSuccess(data) {
    const result = {}
    result['status'] = 'success'
    result['data'] = data
    return result
}

//Error Method
function createError(error) {
    const result = {}
    result['status'] = 'error'
    result['error'] = error
    return result
}

//Export Module
module.exports = {
    checkResult: checkResult,
    createSuccess: createSuccess,
    createError: createError
}