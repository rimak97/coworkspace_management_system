//Import all required
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");


router.get("/getAllallocated", (request, response) => {
    //const queryStatement = `select coworkID, coworkName,address,contactNumber,email,website from coworkspace`
    const queryStatement = `select * from usercospacerolemapping`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });

  
router.delete("/deleteAllocatedById/:userID", (request, response) => {
    const userID = request.params.userID;
    const queryStatement = `delete from usercospacerolemapping where userID=${userID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });
  
  
  router.put("/updateAllocatedByUserID/:userID", (request, response) => {
    const userID = request.params.userID;
    const { roleID,coworkID } = request.body;
    const queryStatement = `update coworkspace set roleID = '${roleID}', coworkID = '${coworkID}' where userID = ${userID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });
  
  
  router.post("/addAllocated", (request, response) => {
    const { userID } = request.body;
    const queryStatement = `insert into coworkspace(coworkID,coworkName, address, contactNumber, email, website) values (default,'${coworkName}', '${address}',  '${contactNumber}', '${email}', '${website}')`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });
  
  
  
  //Export Router Module
  module.exports = router;
  