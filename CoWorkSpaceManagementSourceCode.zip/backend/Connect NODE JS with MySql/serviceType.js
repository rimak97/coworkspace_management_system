// Name of Web Service --> serviceType

// List of all Webservice modules
// 1 Get All Service Types Details
// 2 Get Service Type Detail By serviceTypeID
// 3 Delete Service Type Detail By serviceTypeID
// 4 Update Service Type Details By serviceTypeID
// 5 Add New Service Type.

//Import all required
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All Service Types Details -->Example of URL--> /getAllServiceTypes
router.get("/getAllServiceTypes", (request, response) => {
  const queryStatement = `select * from servicetypes`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 2 Get Service Type Detail By serviceTypeID -->Example of URL--> /getServiceTypeById/:serviceTypeID=/getServiceTypeById/100
router.get("/getServiceTypeById/:serviceTypeID", (request, response) => {
  const serviceTypeID = request.params.serviceTypeID;
  const queryStatement = `select * from servicetypes where serviceTypeID=${serviceTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 3 Delete Service Type Detail By serviceTypeID -->Example of URL--> /deleteServiceTypeById/:serviceTypeID=/deleteServiceTypeById/100
router.delete("/deleteServiceTypeById/:serviceTypeID", (request, response) => {
  const serviceTypeID = request.params.serviceTypeID;
  const queryStatement = `delete from servicetypes where serviceTypeID=${serviceTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 4 Update Service Type Details By serviceTypeID -->Example of URL--> /update/:serviceTypeID=/update/200
router.put("/updateServiceType/:serviceTypeID", (request, response) => {
  const serviceTypeID = request.params.serviceTypeID;
  const serviceTypeName = request.body.serviceTypeName;
  const queryStatement = `update servicetypes set serviceTypeName = '${serviceTypeName}' where serviceTypeID = ${serviceTypeID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 5 Add New Service Type. serviceTypeID is Auto Increament -->Example of URL--> /addServiceType
router.post("/addServiceType", (request, response) => {
  const serviceTypeName = request.body.serviceTypeName;
  const queryStatement = `insert into servicetypes(serviceTypeID, serviceTypeName) values (default,'${serviceTypeName}')`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Export Router Module
module.exports = router;
