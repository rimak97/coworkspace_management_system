const { request, response } = require("express");
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");
const jwt=require("jsonwebtoken");

// 0 Get All Users Details by replacing role ID by name-->Example of URL--> /getAllUserDetails
router.get("/getAllUserDetails",(request,response)=>{
  const queryStatement = `select u.userID,u.firstName,u.middleName,u.lastName,u.address,u.contactNumber,u.email,u.aadharCardNumber,u.password,r.roleName from users u inner join roles r on u.roleID=r.roleID`;
  db.query(queryStatement,(error,data)=>{
      response.send(utility.checkResult(error,data));
  });
});

// 1 Get All Users Details -->Example of URL--> /getAllUserDetails
router.get("/getAllUserDetailsold",(request,response)=>{
    const queryStatement = `select * from users`;
    db.query(queryStatement,(error,data)=>{
        response.send(utility.checkResult(error,data));
    });
});

// 2 Get User Details by userID   -->Example of URL--> /getUserDetailsById/:userID
router.get("/getUserDetailsById/:userID",(request, response) => {
    const userID = request.params.userID;
    const queryStatement = `select u.userID,u.firstName,u.middleName,u.lastName,u.address,u.contactNumber,u.email,u.aadharCardNumber,u.password,r.roleName from users u inner join roles r on u.roleID=r.roleID where userID=${userID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
});


// 3 Delete User by roleID 
router.delete("/deleteUserById/:userID", (request, response) => {
    const userID = request.params.userID;
    const queryStatement = `delete from users where userID=${userID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });
  
  // 4 Update User
  router.put("/updateUser/:userID", (request, response) => {
    const userID = request.params.userID;
    const firstName = request.body.firstName;
    const middleName = request.body.middleName;
    const lastName = request.body.lastName;
    const address = request.body.address;
    const contactNumber = request.body.contactNumber;
    const email = request.body.email;
    const aadharCardNumber = request.body.aadharCardNumber;
    const password = request.body.password;
    const roleID = request.body.roleID;

    
    const queryStatement = `update users set firstName='${firstName}',middleName='${middleName}',lastName='${lastName}',address='${address}',contactNumber='${contactNumber}',email='${email}',aadharCardNumber='${aadharCardNumber}',password='${password}',roleID='${roleID}' where userID = ${userID}`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });
  
  // 5 Add New User
  router.post("/addUser", (request, response) => {
    const firstName = request.body.firstName;
    const middleName = request.body.middleName;
    const lastName = request.body.lastName;
    const address = request.body.address;
    const contactNumber = request.body.contactNumber;
    const email = request.body.email;
    const aadharCardNumber = request.body.aadharCardNumber;
    const password = request.body.password;
    const roleID = request.body.roleID;

    const queryStatement = `insert into users(userID,firstName,middleName,lastName,address,contactNumber,email,aadharCardNumber,password,roleID) values (default,'${firstName}','${middleName}','${lastName}','${address}','${contactNumber}','${email}','${aadharCardNumber}','${password}','${roleID}')`;
    db.query(queryStatement, (error, data) => {
      response.send(utility.checkResult(error, data));
    });
  });


  //Get User Details and JWT Token by Email and Password
  router.post("/getUserByEmail", (request, response) => {
    const email = request.body.email;
    const password = request.body.password;
    
    const queryStatement = `select u.userID,u.firstName,u.middleName,u.lastName,u.address,u.contactNumber,u.email,u.aadharCardNumber,u.password,r.roleName from users u inner join roles r on u.roleID=r.roleID where u.email='${email}' and u.password='${password}'`;
    //const queryStatement = `select * from users where email='${email}' and password='${password}'`;
    db.query(queryStatement, (error, data) => {
      if(error)
      {
        response.send(utility.checkResult(error, data));
      }
      else if(data.length==0)
      {
        response.send({status:"error",error:"User Does Not Exist"});
      }
      else{
        const user=data[0];
        const token=jwt.sign({userID:user['userID']},'123456789');
        const result={
          "firstName":user.firstName,
          "lastName":user.lastName,
          "token":token,
          "roleName":user.roleName,
          "userID":user.userID
        }
        response.send(utility.checkResult(error, result));
      }      
    });
  });


//Export Router Module
module.exports = router;