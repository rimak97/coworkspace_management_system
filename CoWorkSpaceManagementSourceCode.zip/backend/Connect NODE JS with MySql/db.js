const mysql=require("mysql");

//Create MySql Database Connection pool with UserName and Password
var pool = mysql.createPool({
    connectionLimit: 5,
    host: 'localhost',
    user: 'root',
    password: '12345', 
    database: 'cospacedb'
});

//Connect MySql Database  
pool.getConnection(function(error,connection){
    if(error)
        console.log("MySQL Data Base Not Connected.....");
    else
        console.log("MySQL Data Base Connected Sucessfully.....");
});



//Export Connection after Sucess
module.exports=pool;