// Name of Web Service --> roles

// 1 Get All Roles Names
// 2 Get Role Name by roleID
// 3 Delete Role by roleID
// 4 Update Role Name By roleID
// 5 Add New Role Name.

const { request, response } = require("express");
const express = require("express");
const db = require("./db");
const router = express.Router();
const utility = require("./utility");

// 1 Get All Roles Names -->Example of URL--> /getAllRolesName
router.get("/getAllRoleNames", (request, response,jwt) => {
  const queryStatement = `select * from roles`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});


// 1 Get All Roles Names -->Example of URL--> /getAllRolesName
router.get("/getAllRoleNamesforAdmin", (request, response,jwt) => {
  const queryStatement = `select * from roles where roleName!='Super Admin' and roleName!='Admin'`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});



// 2 Get Role Name by roleID -->Example of URL--> /getRoleNameById/:roleID=/getRoleNameById/1
router.get("/getRoleNameById/:roleID", (request, response) => {
  const roleID = request.params.roleID;
  const queryStatement = `select * from roles where roleID=${roleID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 3 Delete Role by roleID -->Example of URL--> /getAllRolesName
router.delete("/deleteRoleById/:roleID", (request, response) => {
  const roleID = request.params.roleID;
  const queryStatement = `delete from roles where roleID=${roleID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 4 Update Role Name By roleID -->Example of URL--> /update/:roleID=/update/4
router.put("/update/:roleID", (request, response) => {
  const roleID = request.params.roleID;
  const roleName = request.body.roleName;
  const queryStatement = `update roles set roleName = '${roleName}' where roleID = ${roleID}`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

// 5 Add New Role Name. roleID is Auto Increament -->Example of URL--> /addRoleName
router.post("/addRoleName", (request, response) => {
  const roleName = request.body.roleName;
  const queryStatement = `insert into roles(roleID, roleName) values (default,'${roleName}')`;
  db.query(queryStatement, (error, data) => {
    response.send(utility.checkResult(error, data));
  });
});

//Export Router Module
module.exports = router;
