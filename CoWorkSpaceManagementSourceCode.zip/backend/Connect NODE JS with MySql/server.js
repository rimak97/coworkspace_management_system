//Import Express
const express = require("express");
const pool = require("./db");
const cospace = require("./cospace");
const serviceType = require("./serviceType");
const planType = require("./planType");
const roleType = require("./roles");
const paymentType = require("./paymenttype");
const coSpacePlanService=require("./coSpacePlanService");
const users=require("./users");
const bookings=require("./bookings");

const jwt=require("jsonwebtoken");

const cors=require("cors");




//Create Express app
const app = express();

//Configure Server Port as 8080
const PORT = 9090;

//Import Body Parser
const bodyParser = require("body-parser");

app.use(cors());

function getUserID(req,res,next){
  if(req.url=='/users/getUserByEmail'|| req.url=='/signUp' ||req.url=='/bookings/addNewBooking'||req.url.startsWith('/users/addUser'))
  {
    next()
  }
  else
  {
    try{
      const token=req.headers['token'];
      //console.log("In Backend Token");
      console.log(token);
      const data=jwt.verify(token,'123456789');
      //console.log("JWT Data");
      //console.log(data);
      //req.userID=data[userID]
      req.id=data['userID']
      //console.log(req.id)
      next()
    }catch(e)
    {
      res.status(401)
      res.send({status:'error',error:'This is Not secured API'})
    }
  }
}
app.use(getUserID)


//Use Body Parser
app.use(bodyParser.json());


//Create Index Page
app.get("/", (req, res) => {
  res.send("Hello World");
});

//Route to CoSpace Router
app.use("/coSpace", cospace);

//Route to Service Type Router
app.use("/serviceType", serviceType);

//Route to Plan Type Router
app.use("/planType", planType);

//Route to Role Type Router
app.use("/roleType", roleType);

//Route to Payment Type Router
app.use("/paymentType", paymentType);

//Route to Payment Type Router
app.use("/coSpacePlanService", coSpacePlanService);

//Route to Users Router
app.use("/users",users);

//Route to Users Router
app.use("/bookings",bookings);





// make the server listen to requests
app.listen(PORT, () => {
  console.log(`Server running at: http://localhost:${PORT}/`);
});


//Export Connection after Sucess
module.exports = app;
